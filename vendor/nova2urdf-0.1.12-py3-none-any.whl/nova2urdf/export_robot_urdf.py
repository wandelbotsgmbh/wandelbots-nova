"""Export robot models to URDF format using the Nova v2 API.

Strategy: fetch model assets (kinematic, collision, GLB) and spin up a
virtual controller **in parallel**.  The assets don't need a controller,
but the controller provides rich metadata (joint limits with velocity &
acceleration, payloads, TCP info, etc.).  By overlapping both operations
the ~17 s controller startup is hidden behind the asset downloads.
"""

import asyncio
import logging
from pathlib import Path
import tempfile
import time
from typing import cast

import httpx
import numpy as np
from numpy.typing import NDArray
from scipy.spatial.transform import Rotation

from .api_client import (
    config_id_for_model,
    create_controller_and_fetch_metadata,
    fetch_collision_setups,
    fetch_config_ids,
    fetch_controller_metadata,
    fetch_controller_motion_groups,
    fetch_model_assets,
    fetch_stored_link_chains,
    fetch_stored_tool_colliders,
    nova_target,
)
from .collision_mesh_extractor import CollisionMeshExtractor
from .constants import DEFAULT_JOINT_LIMIT, DEFAULT_VELOCITY, MM_TO_M
from .controller_export import (
    MotionGroupChain,
    resolve_chain_tree,
    to_chain_exports,
    write_motion_groups_sidecar,
)
from .glb_chains import GlbChains
from .urdf_exporter import (
    DHParam,
    JointLimit,
    Mounting,
    RobotModel,
    TCPDefinition,
    ToolCollider,
    URDFExporter,
)
from .utils import to_float
from .visual_mesh_extractor import VisualMeshExtractor

logger = logging.getLogger(__name__)


# ── DH parameter parsing ─────────────────────────────────────


def _parse_dh_parameters(kinematic: dict[str, object]) -> list[DHParam]:
    """Parse DH parameters from kinematic response."""
    raw_params: object = kinematic.get("dh_parameters", [])
    if not isinstance(raw_params, list):
        return []
    params = cast("list[dict[str, object]]", raw_params)
    return [
        DHParam(
            alpha=to_float(item.get("alpha", 0.0)),
            theta=to_float(item.get("theta", 0.0)),
            a=to_float(item.get("a", 0.0)),
            d=to_float(item.get("d", 0.0)),
            reverse_rotation_direction=bool(
                item.get("reverse_rotation_direction", False)
            ),
        )
        for item in params
    ]


# ── Motion-group metadata parsing ────────────────────────────


def _parse_joint_limits(mg_desc: dict[str, object]) -> list[JointLimit]:
    """Parse joint limits from motion group description."""
    raw_limits: object = mg_desc.get("operation_limits", {})
    if not isinstance(raw_limits, dict):
        return []
    limits = cast("dict[str, object]", raw_limits)
    raw_auto: object = limits.get("auto_limits", {})
    if not isinstance(raw_auto, dict):
        return []
    auto = cast("dict[str, object]", raw_auto)
    raw_joints: object = auto.get("joints", [])
    if not isinstance(raw_joints, list):
        return []
    joints = cast("list[dict[str, object]]", raw_joints)
    result: list[JointLimit] = []
    for item in joints:
        raw_pos: object = item.get("position", {})
        if not isinstance(raw_pos, dict):
            continue
        pos = cast("dict[str, object]", raw_pos)
        result.append(
            JointLimit(
                lower_limit=to_float(
                    pos.get("lower_limit", -DEFAULT_JOINT_LIMIT),
                    -DEFAULT_JOINT_LIMIT,
                ),
                upper_limit=to_float(
                    pos.get("upper_limit", DEFAULT_JOINT_LIMIT),
                    DEFAULT_JOINT_LIMIT,
                ),
                velocity=to_float(item.get("velocity", DEFAULT_VELOCITY)),
            )
        )
    return result


# ── Mesh extraction & URDF generation ─────────────────────────


def _extract_meshes(
    chain: MotionGroupChain,
    export_dir: Path,
    *,
    length_divisor: float = MM_TO_M,
    include_statics: bool = False,
) -> tuple[dict[int, list[dict[str, str]]], dict[int, list[dict[str, str]]]]:
    """Write one chain's collision and visual meshes; return their mesh info."""
    robot, model_id, file_prefix = chain.robot, chain.model_id, chain.prefix
    model_name = model_id.replace("-", "_").lower()

    extractor = CollisionMeshExtractor(
        output_dir=str(export_dir),
        model_name=model_name,
        file_prefix=file_prefix,
        length_divisor=length_divisor,
    )
    collision_info = extractor.extract_link_chain_meshes(chain.link_chain)
    logger.info("Extracted collision meshes for %d links", len(collision_info))

    visual_info: dict[int, list[dict[str, str]]] = {}
    with tempfile.NamedTemporaryFile(suffix=".glb", delete=False) as glb_tmp:
        glb_tmp.write(chain.glb)
        glb_path = Path(glb_tmp.name)
    try:
        visual_extractor = VisualMeshExtractor(
            output_dir=str(export_dir),
            model_name=model_id,
            dh_robot=robot,
            file_prefix=file_prefix,
            length_divisor=length_divisor,
            include_statics=include_statics,
        )
        if visual_extractor.load_model(str(glb_path)):
            visual_info = visual_extractor.extract_visual_meshes()
            logger.info(
                "Extracted %d visual meshes", sum(len(v) for v in visual_info.values())
            )
    finally:
        glb_path.unlink(missing_ok=True)

    return collision_info, visual_info


def _export_dir(model_id: str, output_dir: str | None) -> Path:
    """Directory this export writes into."""
    model_name = model_id.replace("-", "_").lower()
    base = Path(output_dir) if output_dir else Path.home() / "robot_exports"
    export_dir = base / model_name
    export_dir.mkdir(parents=True, exist_ok=True)
    logger.info("Exporting to: %s", export_dir)
    return export_dir


def _export_meshes_and_urdf(
    robot: RobotModel,
    model_id: str,
    link_chain: dict[str, object] | list[object],
    glb_bytes: bytes,
    output_dir: str | None = None,
) -> str:
    """Extract meshes and generate a single-chain URDF. Returns the URDF path."""
    export_dir = _export_dir(model_id, output_dir)
    collision_info, visual_info = _extract_meshes(
        MotionGroupChain(
            motion_group_id="",
            model_id=model_id,
            robot=robot,
            glb=glb_bytes,
            link_chain=link_chain,
            chains=GlbChains.from_bytes(glb_bytes),
        ),
        export_dir,
    )

    exporter = URDFExporter(
        robot=robot,
        model_name=model_id.replace("-", "_").lower(),
        export_path=str(export_dir),
        collision_meshes_info=collision_info,
        visual_meshes_info=visual_info,
    )
    return exporter.export_urdf()


def _rotvec_to_rpy(orientation: object) -> list[float]:
    """A Nova rotation vector as the xyz Euler angles URDF's ``rpy`` wants.

    Nova states every orientation as a rotation vector (axis times angle). URDF
    reads ``rpy`` as roll-pitch-yaw, so passing one through unconverted points a
    tool in the wrong direction -- close enough to look plausible, wrong enough
    to matter.
    """
    if not isinstance(orientation, list) or not orientation:
        return [0.0, 0.0, 0.0]
    rotvec = [to_float(value) for value in cast("list[object]", orientation)]
    if not any(rotvec):
        return [0.0, 0.0, 0.0]
    return [float(value) for value in Rotation.from_rotvec(rotvec).as_euler("xyz")]


def _pose_to_mounting(raw: object) -> Mounting | None:
    """A Nova pose as a ``Mounting``, or ``None`` if it is absent or zero.

    Nova states an orientation as a rotation vector; ``Mounting`` holds xyz
    Euler angles, so convert here rather than leaving two conventions in play.
    """
    if not isinstance(raw, dict):
        return None
    pose = cast("dict[str, object]", raw)
    position = pose.get("position")
    orientation = pose.get("orientation")
    if not isinstance(position, list) or not isinstance(orientation, list):
        return None
    xyz = [to_float(value) for value in cast("list[object]", position)]
    rpy = _rotvec_to_rpy(cast("list[object]", orientation))
    if not any(xyz) and not any(rpy):
        return None
    return Mounting(position=xyz, orientation=rpy)


def _mounting_matrix(mounting: Mounting) -> NDArray[np.float64]:
    """A ``Mounting`` as a 4x4 transform, in whatever units it carries."""
    matrix: NDArray[np.float64] = np.eye(4)
    matrix[:3, :3] = Rotation.from_euler("xyz", mounting.orientation).as_matrix()
    matrix[:3, 3] = mounting.position
    return matrix


def _compose_mountings(outer: Mounting, inner: Mounting) -> Mounting:
    """*inner* expressed in *outer*'s frame, as a single mounting."""
    composed: NDArray[np.float64] = _mounting_matrix(outer) @ _mounting_matrix(inner)
    return Mounting(
        position=cast(
            "list[float]", np.asarray(composed[:3, 3], dtype=np.float64).tolist()
        ),
        orientation=cast(
            "list[float]",
            np.asarray(
                Rotation.from_matrix(composed[:3, :3]).as_euler("xyz"), dtype=np.float64
            ).tolist(),
        ),
    )


def _parse_mounting(mg_desc: dict[str, object]) -> Mounting:
    """Where this motion group's base sits, relative to what it is mounted on.

    The two fields mean different things and a robot can report both:
    ``mounting`` places the robot in the cell, ``kinematic_chain_offset``
    offsets the chain from that mount point (a base column, for instance).
    Nova's own forward kinematics applies both, so compose them rather than
    picking one -- a Stäubli TX2-60 mounted 4.5 m along Y reports a 375 mm
    offset as well, and dropping either field puts it metres from where the
    controller says it is.

    The mounting is the outer transform: the mount point is a place in the
    cell, and the chain offset is a property of the robot standing on it. A
    robot that fills in only one field is unaffected either way. Where both are
    absent the GLB's authored chain root is the last resort (see
    :func:`nova2urdf.controller_export.resolve_chain_tree`).
    """
    offset = _pose_to_mounting(mg_desc.get("kinematic_chain_offset"))
    mounting = _pose_to_mounting(mg_desc.get("mounting"))
    if offset is not None and mounting is not None:
        return _compose_mountings(mounting, offset)
    return offset or mounting or Mounting()


# ── TCP parsing ───────────────────────────────────────────────


def _parse_all_tcps(mg_desc: dict[str, object]) -> list[TCPDefinition]:
    """Every TCP this motion group defines, in the order the API lists them."""
    raw: object = mg_desc.get("tcps", {})
    if not isinstance(raw, dict):
        return []
    tcps = cast("dict[str, dict[str, object]]", raw)
    found: list[TCPDefinition] = []
    for key, tcp_data in tcps.items():
        pose = cast("dict[str, object]", tcp_data.get("pose", {}))
        position = pose.get("position")
        found.append(
            TCPDefinition(
                id=key,
                name=str(tcp_data.get("name", key)),
                position=[to_float(v) for v in cast("list[object]", position)]
                if isinstance(position, list)
                else [0.0, 0.0, 0.0],
                orientation=_rotvec_to_rpy(pose.get("orientation")),
            )
        )
    return found


def _parse_tcp(
    mg_desc: dict[str, object],
    tcp_name: str | None,
) -> TCPDefinition:
    """Parse a TCP definition from motion group description.

    If *tcp_name* is ``None``, returns the default (identity) TCP.
    Raises ``ValueError`` if the requested TCP is not found.
    """
    if tcp_name is None:
        return TCPDefinition()

    raw_tcps: object = mg_desc.get("tcps", {})
    if not isinstance(raw_tcps, dict):
        return TCPDefinition()
    tcps = cast("dict[str, dict[str, object]]", raw_tcps)

    # Try exact key match first, then case-insensitive name match
    for key, tcp_data in tcps.items():
        name = str(tcp_data.get("name", key))
        if tcp_name in {key, name}:
            pose = cast("dict[str, list[float]]", tcp_data.get("pose", {}))
            return TCPDefinition(
                name=name,
                position=pose.get("position", [0.0, 0.0, 0.0]),
                orientation=_rotvec_to_rpy(pose.get("orientation")),
            )

    # Case-insensitive fallback
    lower = tcp_name.lower()
    for key, tcp_data in tcps.items():
        name = str(tcp_data.get("name", key))
        if key.lower() == lower or name.lower() == lower:
            pose = cast("dict[str, list[float]]", tcp_data.get("pose", {}))
            return TCPDefinition(
                name=name,
                position=pose.get("position", [0.0, 0.0, 0.0]),
                orientation=_rotvec_to_rpy(pose.get("orientation")),
            )

    available = [str(t.get("name", k)) for k, t in tcps.items()]
    msg = f"TCP '{tcp_name}' not found. Available TCPs: {available}"
    raise ValueError(msg)


# ── Tool collision fetching ────────────────────────────────────


def _parse_colliders_from_tool(
    tool_data: dict[str, object],
    source: str,
) -> list[ToolCollider]:
    """Parse a Tool dict (name -> Collider) into ToolCollider list."""
    result: list[ToolCollider] = []
    for name, raw_collider in tool_data.items():
        if not isinstance(raw_collider, dict):
            continue
        collider = cast("dict[str, object]", raw_collider)
        shape = collider.get("shape", {})
        if not isinstance(shape, dict):
            continue
        raw_pose: object = collider.get("pose", {})
        pose = (
            cast("dict[str, list[float]]", raw_pose)
            if isinstance(raw_pose, dict)
            else {}
        )
        result.append(
            ToolCollider(
                name=f"{source}_{name}",
                shape=cast("dict[str, object]", shape),
                position=pose.get("position", [0.0, 0.0, 0.0]),
                orientation=_rotvec_to_rpy(pose.get("orientation")),
                margin=to_float(collider.get("margin", 0)),
            )
        )
    return result


def _parse_safety_link_colliders(
    mg_desc: dict[str, object],
) -> dict[int, list[ToolCollider]]:
    """The safety controller's volumes per link, from the motion group description.

    The API lists one entry per link, in that link's own frame, so the index is
    the link's index and needs no translation.
    """
    raw: object = mg_desc.get("safety_link_colliders")
    if not isinstance(raw, list):
        return {}
    result: dict[int, list[ToolCollider]] = {}
    for index, entry in enumerate(cast("list[object]", raw)):
        if not isinstance(entry, dict):
            continue
        colliders = _parse_colliders_from_tool(
            cast("dict[str, object]", entry), f"safety_link_{index}"
        )
        if colliders:
            result[index] = colliders
    return result


def _parse_safety_tool_colliders(mg_desc: dict[str, object]) -> list[ToolCollider]:
    """The safety controller's volumes per TCP, in the flange frame.

    Every TCP's, because the description does not say which tool is mounted --
    that is runtime state, not robot data. They are all stated in the flange
    frame, so they all hang there, each named ``safety_tool_<tcp>_...`` for a
    consumer to pick the one it is driving.
    """
    raw: object = mg_desc.get("safety_tool_colliders")
    if not isinstance(raw, dict):
        return []
    result: list[ToolCollider] = []
    for tcp, entry in cast("dict[str, object]", raw).items():
        if isinstance(entry, dict):
            result.extend(
                _parse_colliders_from_tool(
                    cast("dict[str, object]", entry), f"safety_tool_{tcp}"
                )
            )
    return result


async def _fetch_tool_colliders(
    client: httpx.AsyncClient,
    tool_name: str | None = None,
    *,
    collision_setups: dict[str, dict[str, object]] | None = None,
) -> list[ToolCollider]:
    """Fetch tool collision shapes from stored tools and safety setups.

    If *collision_setups* is provided it is reused instead of fetching again.
    """
    if collision_setups is not None:
        raw_stored = await fetch_stored_tool_colliders(client, tool_name=tool_name)
        raw_setups = collision_setups
    else:
        raw_stored, raw_setups = await asyncio.gather(
            fetch_stored_tool_colliders(client, tool_name=tool_name),
            fetch_collision_setups(client),
        )

    result: list[ToolCollider] = []

    # Parse stored tool colliders
    for tname, tdata in raw_stored.items():
        colliders = _parse_colliders_from_tool(
            tdata,
            f"tool_{tname}" if tname != "tool" else "tool",
        )
        result.extend(colliders)

    if result:
        logger.info("Loaded %d stored tool collision shapes", len(result))

    # Parse safety setup tool colliders
    for sname, setup in raw_setups.items():
        raw_tool: object = setup.get("tool", {})
        if not isinstance(raw_tool, dict) or not raw_tool:
            continue
        colliders = _parse_colliders_from_tool(
            cast("dict[str, object]", raw_tool), f"safety_{sname}"
        )
        result.extend(colliders)
        if colliders:
            logger.info(
                "Loaded %d safety tool shapes from setup '%s'",
                len(colliders),
                sname,
            )

    return result


# ── Link-chain collision merging ──────────────────────────────


def _merge_link_chains(
    base: list[object],
    *extras: list[object],
) -> list[object]:
    """Merge multiple link-chain collision lists.

    Each link-chain is a list of dicts (link_idx → {collider_name: collider}).
    Colliders from *extras* are added to the *base* per link, with prefixed
    names to avoid key collisions.
    """
    # Work on a mutable copy
    merged = [
        dict(cast("dict[str, object]", item)) if isinstance(item, dict) else {}
        for item in base
    ]

    for extra in extras:
        for i, item in enumerate(extra):
            if not isinstance(item, dict) or not item:
                continue
            # Extend merged list if extra has more links
            while len(merged) <= i:
                merged.append({})
            merged[i].update(cast("dict[str, object]", item))

    return list(merged)


async def _fetch_extra_link_chains(
    client: httpx.AsyncClient,
    *,
    collision_setups: dict[str, dict[str, object]] | None = None,
) -> list[list[object]]:
    """Fetch stored and safety link-chains to merge with the model default.

    If *collision_setups* is provided it is reused instead of fetching again.
    """
    if collision_setups is not None:
        raw_stored = await fetch_stored_link_chains(client)
        raw_setups = collision_setups
    else:
        raw_stored, raw_setups = await asyncio.gather(
            fetch_stored_link_chains(client),
            fetch_collision_setups(client),
        )

    result: list[list[object]] = []

    # Stored link-chains
    for name, chain in raw_stored.items():
        if chain:
            result.append(chain)
            logger.info("Loaded stored link-chain '%s' (%d links)", name, len(chain))

    # Safety setup link-chains
    for sname, setup in raw_setups.items():
        raw_lc: object = setup.get("link_chain", [])
        if isinstance(raw_lc, list) and raw_lc:
            result.append(cast("list[object]", raw_lc))
            logger.info(
                "Loaded safety link-chain from setup '%s' (%d links)",
                sname,
                len(cast("list[object]", raw_lc)),
            )

    return result


# ── Public API ────────────────────────────────────────────────


async def _fetch_motion_group_chain(
    client: httpx.AsyncClient,
    controller_name: str,
    motion_group_id: str,
    tcp_name: str | None,
    collision_setups: dict[str, dict[str, object]],
) -> MotionGroupChain | None:
    """Fetch one motion group's description and model assets."""
    result = await fetch_controller_metadata(client, controller_name, motion_group_id)
    if result is None:
        return None
    model_id, mg_desc = result

    # A TCP belongs to a motion group, not to the controller: on a multi-part
    # robot only some parts carry the gripper, and asking the carrier for it
    # would fail the whole export. Take the named one where it exists and the
    # flange everywhere else, and say which was used.
    try:
        tcp = _parse_tcp(mg_desc, tcp_name)
    except ValueError as exc:
        logger.info("%s: %s; using its flange instead", motion_group_id, exc)
        tcp = TCPDefinition()
    if tcp_name:
        logger.info("%s: tool0 at TCP %r", motion_group_id, tcp.name)
    kinematic, link_chain, glb_bytes = await fetch_model_assets(client, model_id)

    tool_colliders, extra_chains = await asyncio.gather(
        _fetch_tool_colliders(
            client, tool_name=tcp_name, collision_setups=collision_setups
        ),
        _fetch_extra_link_chains(client, collision_setups=collision_setups),
    )
    if extra_chains:
        link_chain = _merge_link_chains(cast("list[object]", link_chain), *extra_chains)
        logger.info(
            "Merged %d extra link-chain(s) into %s", len(extra_chains), motion_group_id
        )

    robot = RobotModel(
        dh_parameters=_parse_dh_parameters(kinematic),
        mounting=_parse_mounting(mg_desc),
        joint_limits=_parse_joint_limits(mg_desc),
        tcp=tcp,
        tool_colliders=tool_colliders,
        tcps=_parse_all_tcps(mg_desc),
        safety_link_colliders=_parse_safety_link_colliders(mg_desc),
        safety_tool_colliders=_parse_safety_tool_colliders(mg_desc),
    )
    return MotionGroupChain(
        motion_group_id=motion_group_id,
        model_id=model_id,
        robot=robot,
        glb=glb_bytes,
        link_chain=link_chain,
        chains=GlbChains.from_bytes(glb_bytes),
    )


def _write_controller_urdf(
    chains: list[MotionGroupChain],
    export_dir: Path,
    controller_name: str,
    *,
    length_divisor: float,
    tool_assets: dict[str, str] | None,
) -> str:
    """Write every chain's meshes and the URDF that ties them together.

    Mesh decoding and writing is the one part of an export that is neither
    network nor trivial — seconds of it for a large robot — so it runs in a
    worker thread and leaves the event loop free for other exports.
    """
    # Only the part at the robot's base brings the fixed structure; every
    # model carries a copy of it and four copies would be drawn.
    base = next(
        (c.motion_group_id for c in chains if c.parent_motion_group is None), None
    )
    meshes = {
        chain.motion_group_id: _extract_meshes(
            chain,
            export_dir,
            length_divisor=length_divisor,
            include_statics=chain.motion_group_id == base,
        )
        for chain in chains
    }

    exports = to_chain_exports(chains, meshes)
    urdf_path = URDFExporter(
        chains=exports,
        model_name=controller_name.replace("-", "_").lower(),
        export_path=str(export_dir),
        length_divisor=length_divisor,
        tool_assets=tool_assets,
    ).export_urdf()

    write_motion_groups_sidecar(
        export_dir,
        controller_name,
        Path(urdf_path).name,
        list(zip(chains, exports, strict=True)),
        length_divisor=length_divisor,
    )
    return urdf_path


async def export_controller(  # noqa: PLR0913  # one export, several knobs
    client: httpx.AsyncClient,
    controller_name: str,
    tcp_name: str | None = None,
    output_dir: str | None = None,
    *,
    length_divisor: float = MM_TO_M,
    tool_assets: dict[str, str] | None = None,
    nova_url: str | None = None,
    cell: str | None = None,
) -> str | None:
    """Export a Nova controller to a single URDF. The controller is never deleted.

    Every motion group of the controller becomes one chain of the URDF. A
    multi-part robot (a carrier chain with further chains mounted on it) comes
    out as one tree, with each part mounted where the models say it is mounted,
    so driving the carrier's joints moves the parts riding on it. Names are
    namespaced
    ``mg<n>_`` per motion group; ``motion_groups.json`` beside the URDF maps
    each motion group to its joint names in joint order.

    A single-motion-group controller exports exactly as it always did.

    If *tcp_name* is provided, each chain's ``tool0`` frame sits at that TCP's
    offset; otherwise ``tool0`` is at the flange. *length_divisor* is
    millimetres per URDF length unit: 1000 for a metre URDF (the default and
    what every standard consumer expects), 1 for a millimetre one.

    *tool_assets* are tool meshes the API does not serve, keyed by the frame
    they mount on: a TCP id or name, ``tool0``, or ``flange``. Every TCP is its
    own frame in the URDF, so a robot with several tools shows each one where it
    really sits.

    *nova_url* and *cell* name the Nova instance for this one export; without
    them it comes from the environment. Pass them when one process serves more
    than one instance, and keep credentials on *client*.
    """
    with nova_target(nova_url, cell):
        return await _export_controller(
            client,
            controller_name,
            tcp_name,
            output_dir,
            length_divisor=length_divisor,
            tool_assets=tool_assets,
        )


async def _export_controller(  # noqa: PLR0913  # one export, several knobs
    client: httpx.AsyncClient,
    controller_name: str,
    tcp_name: str | None = None,
    output_dir: str | None = None,
    *,
    length_divisor: float = MM_TO_M,
    tool_assets: dict[str, str] | None = None,
) -> str | None:
    """Export a Nova controller to a single URDF. The controller is never deleted."""
    try:
        t0 = time.monotonic()

        motion_group_ids = await fetch_controller_motion_groups(client, controller_name)
        if not motion_group_ids:
            return None
        logger.info(
            "Controller '%s' has motion groups %s", controller_name, motion_group_ids
        )

        # Setups are shared by every motion group, so fetch them once.
        collision_setups = await fetch_collision_setups(client)
        fetched = await asyncio.gather(*[
            _fetch_motion_group_chain(
                client, controller_name, mg_id, tcp_name, collision_setups
            )
            for mg_id in motion_group_ids
        ])
        chains = [chain for chain in fetched if chain is not None]
        if not chains:
            logger.error("No motion group of '%s' could be read", controller_name)
            return None
        logger.info("[bench] Fetch assets + colliders: %.2fs", time.monotonic() - t0)

        chains = resolve_chain_tree(chains)
        for chain in chains:
            if chain.parent_motion_group:
                logger.info(
                    "%s mounts on %s joint %s",
                    chain.motion_group_id,
                    chain.parent_motion_group,
                    chain.parent_joint_index,
                )

        export_dir = _export_dir(controller_name, output_dir)
        urdf_path = await asyncio.to_thread(
            _write_controller_urdf,
            chains,
            export_dir,
            controller_name,
            length_divisor=length_divisor,
            tool_assets=tool_assets,
        )
        logger.info("[bench] Total: %.2fs", time.monotonic() - t0)
        logger.info("URDF exported to: %s", urdf_path)
        return urdf_path

    except ValueError:
        logger.exception("Invalid TCP for controller %s", controller_name)
        return None
    except httpx.HTTPError:
        logger.exception("Error exporting controller %s", controller_name)
        return None


async def export_robot(  # noqa: PLR0913  # one export, several knobs
    client: httpx.AsyncClient,
    model_id: str,
    config_ids: list[str] | None = None,
    output_dir: str | None = None,
    *,
    nova_url: str | None = None,
    cell: str | None = None,
) -> str | None:
    """Export a single robot model to URDF.

    Fetches model assets and controller metadata **in parallel**.
    The assets (kinematic, collision, GLB) come from
    ``/motion-group-models/`` (instant), while joint limits and other
    rich metadata come from a temporary virtual controller (~17 s).

    If *config_ids* is provided it is used to look up the controller
    configuration; otherwise a fresh list is fetched from the API.

    *nova_url* and *cell* name the Nova instance for this one export; without
    them it comes from the environment. Pass them when one process serves more
    than one instance, and keep credentials on *client*.
    """
    with nova_target(nova_url, cell):
        return await _export_robot(client, model_id, config_ids, output_dir)


async def _export_robot(
    client: httpx.AsyncClient,
    model_id: str,
    config_ids: list[str] | None = None,
    output_dir: str | None = None,
) -> str | None:
    """Export a single robot model to URDF."""
    try:
        t0 = time.monotonic()

        # Resolve config_id for the controller
        if config_ids is None:
            config_ids = await fetch_config_ids(client)
        config_id = config_id_for_model(model_id, config_ids)

        # Launch asset fetch and controller startup concurrently
        assets_task = asyncio.create_task(fetch_model_assets(client, model_id))
        metadata_task: asyncio.Task[dict[str, object]] | None = None
        if config_id:
            metadata_task = asyncio.create_task(
                create_controller_and_fetch_metadata(client, config_id)
            )
        else:
            logger.warning(
                "No robot-configuration found for %s — joint limits will use defaults",
                model_id,
            )

        kinematic, link_chain, glb_bytes = await assets_task
        t_assets = time.monotonic()
        logger.info("[bench] Fetch assets: %.2fs", t_assets - t0)

        # Wait for controller metadata (may already be done)
        mg_desc: dict[str, object] = {}
        if metadata_task:
            mg_desc = await metadata_task
            t_meta = time.monotonic()
            logger.info("[bench] Controller metadata: %.2fs", t_meta - t0)

        # Build RobotModel with full data
        t_build = time.monotonic()
        robot = RobotModel(
            dh_parameters=_parse_dh_parameters(kinematic),
            mounting=Mounting(),  # always identity for standard URDF
            joint_limits=_parse_joint_limits(mg_desc),
        )

        urdf_path = await asyncio.to_thread(
            _export_meshes_and_urdf,
            robot,
            model_id,
            link_chain,
            glb_bytes,
            output_dir=output_dir,
        )
        t_done = time.monotonic()
        logger.info("[bench] Mesh extraction + URDF: %.2fs", t_done - t_build)
        logger.info("[bench] Total: %.2fs", t_done - t0)
        logger.info("URDF exported to: %s", urdf_path)
        return urdf_path

    except httpx.HTTPError:
        logger.exception("Error exporting %s", model_id)
        return None
