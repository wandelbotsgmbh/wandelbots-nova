"""Collision mesh extraction from robot link colliders."""

import logging
from pathlib import Path
from typing import cast

from .constants import MM_TO_M
from .shape_converter import shape_to_mesh

logger = logging.getLogger(__name__)


class CollisionMeshExtractor:
    """Extracts collision meshes from robot link colliders and saves them as STL files."""

    def __init__(
        self,
        output_dir: str | None = None,
        model_name: str | None = None,
        *,
        file_prefix: str = "",
        length_divisor: float = MM_TO_M,
    ) -> None:
        self.output_dir = output_dir or "robot_export"
        self.model_name = model_name or "robot"
        self.file_prefix = file_prefix
        """Prefix for written filenames, so chains sharing a directory do not collide."""
        self.length_divisor = length_divisor
        """Millimetres per URDF length unit: 1000 for metres, 1 for millimetres."""

    def ensure_output_directory(self) -> Path:
        """Ensure the collision mesh output directory exists."""
        mesh_dir = Path(self.output_dir) / "collision"
        mesh_dir.mkdir(parents=True, exist_ok=True)
        return mesh_dir

    def extract_link_chain_meshes(
        self, link_chain: dict[str, object] | list[object]
    ) -> dict[int, list[dict[str, str]]]:
        """Extract meshes from a link chain (list or dict)."""
        result: dict[int, list[dict[str, str]]] = {}

        if isinstance(link_chain, list):
            for link_idx, raw_collider_dict in enumerate(link_chain):
                collider_dict = cast("dict[str, dict[str, object]]", raw_collider_dict)
                result[link_idx] = self._extract_link_meshes(collider_dict, link_idx)
        else:
            for link_idx_key, raw_collider_dict in link_chain.items():
                collider_dict = cast("dict[str, dict[str, object]]", raw_collider_dict)
                result[int(link_idx_key)] = self._extract_link_meshes(
                    collider_dict, int(link_idx_key)
                )

        return result

    def _extract_link_meshes(
        self,
        collider_dict: dict[str, dict[str, object]],
        link_idx: int,
    ) -> list[dict[str, str]]:
        """Extract meshes for a single link."""
        link_meshes: list[dict[str, str]] = []
        for collider_id, collider in collider_dict.items():
            mesh_file = self._extract_and_save_collider_mesh(
                collider, link_idx, collider_id
            )
            if mesh_file:
                link_meshes.append({"file": mesh_file, "collider_id": collider_id})
        return link_meshes

    def _extract_and_save_collider_mesh(
        self,
        collider: dict[str, object],
        link_idx: int | None,
        collider_id: str,
    ) -> str | None:
        """Extract and save a single collider mesh to STL."""
        if not collider or "shape" not in collider:
            return None

        shape = collider["shape"]
        if not isinstance(shape, dict):
            return None

        shape_dict = cast("dict[str, object]", shape)

        mesh = shape_to_mesh(shape_dict, length_divisor=self.length_divisor)
        if mesh is None:
            return None

        output_dir = self.ensure_output_directory()
        filename = f"{self.file_prefix}link_{link_idx}_{collider_id}.stl"
        filepath = output_dir / filename

        mesh.export(str(filepath))  # pyright: ignore[reportUnknownMemberType]
        return str(filepath)
