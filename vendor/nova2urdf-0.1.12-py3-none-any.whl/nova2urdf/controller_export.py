"""Export a whole Nova controller as one URDF.

A controller can drive several motion groups: a multi-part robot is a carrier
plus the parts riding on it, each its own motion group with its own model and
GLB. They are one robot, so they belong in one URDF, with the riding parts
parented to the carrier's flange so they move along with it.

The parent/child structure is not in the API. It is authored in the GLBs: the
carrier's model carries the riding parts' chains as ``_save`` decoration,
hanging off the carrier's own last joint. See :mod:`nova2urdf.glb_chains`.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import logging
from typing import TYPE_CHECKING, cast

import numpy as np
from scipy.spatial.transform import Rotation

from .constants import MM_TO_M
from .urdf_exporter import ChainExport, Mounting, tcp_frame_name

if TYPE_CHECKING:
    from pathlib import Path

    from numpy.typing import NDArray

    from .glb_chains import GlbChains
    from .urdf_exporter import RobotModel

logger = logging.getLogger(__name__)

_MOTION_GROUPS_SIDECAR = "motion_groups.json"


@dataclass
class MotionGroupChain:
    """One motion group's chain, before its URDF names are fixed."""

    motion_group_id: str
    model_id: str
    robot: RobotModel
    glb: bytes
    link_chain: dict[str, object] | list[object]
    chains: GlbChains
    prefix: str = ""
    """Namespace for this chain's link and joint names."""
    parent_motion_group: str | None = None
    """The motion group this chain rides on, if any."""
    parent_joint_index: int | None = None
    """Which of the parent's joints it hangs off."""

    @property
    def own_prefix(self) -> str | None:
        """This chain's node-name prefix in its own GLB."""
        return self.chains.own_prefix(self.model_id)


def _mounting_from_matrix(transform: NDArray[np.float64]) -> Mounting:
    """A Z-up metre transform as a ``Mounting`` (millimetres plus xyz Euler)."""
    translation = cast(
        "list[float]", np.asarray(transform[:3, 3], dtype=np.float64).tolist()
    )
    euler = cast(
        "list[float]",
        np.asarray(
            Rotation.from_matrix(transform[:3, :3]).as_euler("xyz"), dtype=np.float64
        ).tolist(),
    )
    return Mounting(
        position=[value * MM_TO_M for value in translation],
        orientation=euler,
    )


def _is_zero(mounting: Mounting) -> bool:
    """Whether a mounting is the identity."""
    return not any(mounting.position) and not any(mounting.orientation)


def resolve_chain_tree(chains: list[MotionGroupChain]) -> list[MotionGroupChain]:
    """Fill in prefixes, parents and mountings, and order parents first.

    A single-chain controller keeps empty names and the mounting it came with,
    so its URDF is exactly what it always was. With several chains, each gets an
    ``mg<n>_`` namespace and the placement authored in the GLBs, because the API
    reports a zero mounting for every part of a multi-part robot.
    """
    if len(chains) == 1:
        return chains

    by_id = {chain.motion_group_id: chain for chain in chains}

    for index, chain in enumerate(chains):
        chain.prefix = f"mg{index}_"

    for chain in chains:
        _find_parent(chain, chains)

    for chain in chains:
        own = chain.own_prefix
        if own is not None and _is_zero(chain.robot.mounting):
            # The GLB authors the chain root where it really sits; for a child
            # part that is already relative to its parent's flange frame.
            chain.robot.mounting = _mounting_from_matrix(chain.chains.mounting_zup(own))

    return _order_parents_first(chains, by_id)


def _find_parent(chain: MotionGroupChain, chains: list[MotionGroupChain]) -> None:
    """Set ``chain``'s parent by asking the other models who carries its chain.

    A model that carries this chain as ``_save`` decoration is the part this one
    is mounted on, and where the decoration hangs says which of that part's
    joints to attach to.
    """
    own = chain.own_prefix
    if own is None:
        return
    for other in chains:
        other_own = other.own_prefix
        if other is chain or other_own is None:
            continue
        attachment = other.chains.attachment(own, other_own)
        if attachment is not None:
            chain.parent_motion_group = other.motion_group_id
            chain.parent_joint_index = attachment.joint_index
            return


def _order_parents_first(
    chains: list[MotionGroupChain], by_id: dict[str, MotionGroupChain]
) -> list[MotionGroupChain]:
    """Depth-first order so a chain is always emitted after what it mounts on."""
    ordered: list[MotionGroupChain] = []
    placed: set[str] = set()

    def place(chain: MotionGroupChain, seen: frozenset[str]) -> None:
        if chain.motion_group_id in placed:
            return
        if chain.motion_group_id in seen:
            logger.warning(
                "Cycle in the chain tree at %s; mounting it on the world instead",
                chain.motion_group_id,
            )
            chain.parent_motion_group = None
            chain.parent_joint_index = None
        elif chain.parent_motion_group is not None:
            place(by_id[chain.parent_motion_group], seen | {chain.motion_group_id})
        placed.add(chain.motion_group_id)
        ordered.append(chain)

    for chain in chains:
        place(chain, frozenset())
    return ordered


def to_chain_exports(
    chains: list[MotionGroupChain],
    meshes: dict[
        str, tuple[dict[int, list[dict[str, str]]], dict[int, list[dict[str, str]]]]
    ],
) -> list[ChainExport]:
    """Turn resolved motion-group chains into exporter chains.

    *meshes* maps motion group id to its ``(collision, visual)`` mesh info.
    """
    exports: dict[str, ChainExport] = {}
    result: list[ChainExport] = []

    for chain in chains:
        collision, visual = meshes.get(chain.motion_group_id, ({}, {}))
        parent_link = "world"
        if chain.parent_motion_group is not None:
            parent = exports.get(chain.parent_motion_group)
            if parent is None:
                logger.warning(
                    "Parent %s of %s was not exported; mounting on the world",
                    chain.parent_motion_group,
                    chain.motion_group_id,
                )
            else:
                # The joint index the decoration hangs off is the frame *after*
                # that joint, which is the passive link the exporter emits.
                parent_link = (
                    f"{parent.prefix}link{(chain.parent_joint_index or 0) + 1}_passive"
                )

        export = ChainExport(
            robot=chain.robot,
            prefix=chain.prefix,
            parent_link=parent_link,
            collision_meshes_info=collision,
            visual_meshes_info=visual,
        )
        exports[chain.motion_group_id] = export
        result.append(export)

    return result


def write_motion_groups_sidecar(
    export_dir: Path,
    controller_name: str,
    urdf_filename: str,
    pairs: list[tuple[MotionGroupChain, ChainExport]],
    *,
    length_divisor: float = MM_TO_M,
) -> Path:
    """Write the motion group to URDF joint mapping next to the URDF.

    A consumer driving the URDF from live robot state needs to know which URDF
    joints belong to which motion group, in that motion group's joint order.
    The names follow from the export, so this is an index of it rather than a
    second source of truth.
    """
    payload = {
        "controller": controller_name,
        "urdf": urdf_filename,
        "length_unit": "m" if length_divisor == MM_TO_M else "mm",
        "motion_groups": [
            {
                "motion_group": chain.motion_group_id,
                "model": chain.model_id,
                "prefix": export.prefix,
                "joints": export.joint_names,
                "flange_link": export.flange_link,
                "tool0_link": f"{export.prefix}tool0",
                "tcp": chain.robot.tcp.name,
                "tcps": {
                    tcp.id
                    or tcp.name: f"{export.prefix}{tcp_frame_name(tcp.id or tcp.name)}"
                    for tcp in chain.robot.tcps
                },
                "parent_link": export.parent_link,
            }
            for chain, export in pairs
        ],
    }
    path = export_dir / _MOTION_GROUPS_SIDECAR
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return path
