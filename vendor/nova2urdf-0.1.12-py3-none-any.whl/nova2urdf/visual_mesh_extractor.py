"""Extract per-link GLB visual meshes from a Draco-compressed robot GLB model."""

import logging
from pathlib import Path
from typing import IO, cast

import DracoPy
import numpy as np
from numpy.typing import NDArray
import pygltflib
from scipy.spatial.transform import Rotation

from .buffer_entry import BufferEntry
from .constants import (
    COMPONENT_UINT8,
    COMPONENT_UINT16,
    COMPONENT_UINT32,
    KHR_DRACO_MESH_COMPRESSION,
    MM_TO_M,
)
from .glb_chains import YUP_TO_ZUP as _YUP_TO_ZUP, GlbChains
from .primitive_data import PrimitiveData
from .urdf_exporter import RobotModel

logger = logging.getLogger(__name__)

_COMPONENT_TYPE_MAP: dict[int, type] = {
    COMPONENT_UINT8: np.uint8,
    COMPONENT_UINT16: np.uint16,
    COMPONENT_UINT32: np.uint32,
}


def _translate_z(d: float) -> NDArray[np.float64]:
    """Create a 4x4 translation matrix along Z axis."""
    mat: NDArray[np.float64] = np.eye(4)
    mat[2, 3] = d
    return mat


def _translate_x(a: float) -> NDArray[np.float64]:
    """Create a 4x4 translation matrix along X axis."""
    mat: NDArray[np.float64] = np.eye(4)
    mat[0, 3] = a
    return mat


def _rotate_z(theta: float) -> NDArray[np.float64]:
    """Create a 4x4 rotation matrix around Z axis."""
    mat: NDArray[np.float64] = np.eye(4)
    mat[:3, :3] = Rotation.from_euler("z", theta).as_matrix()
    return mat


def _rotate_x(alpha: float) -> NDArray[np.float64]:
    """Create a 4x4 rotation matrix around X axis."""
    mat: NDArray[np.float64] = np.eye(4)
    mat[:3, :3] = Rotation.from_euler("x", alpha).as_matrix()
    return mat


_PER_LINK_GEOMETRY_MODELS = frozenset({"yaskawahc10dtp"})
"""Models whose geometry does not agree with their own DH parameters.

Named one by one on purpose. A Yaskawa HC10DTP's GLB authors joint 5 mirrored
(y=-162) against the DH parameters the API reports for it (y=+162), and Nova's
own forward kinematics follows the parameters, so no single offset can put that
model's links on their joints. Placing each link on the joint the GLB gives it
keeps every link attached and turning about its own axis, which is the best a
URDF can do for a model whose two halves disagree.
"""


_PER_LINK_GEOMETRY_WARNING = (
    "%s: this model's geometry disagrees with its own DH parameters, so each"
    " link's meshes are placed on the joint the GLB gives them rather than on"
    " one shared offset. The kinematics is unchanged and still matches the"
    " controller; expect a visible seam where the two disagree."
)


def _normalise_model(name: str) -> str:
    """A model id reduced to letters and digits, for table lookups."""
    return "".join(character for character in name.lower() if character.isalnum())


class VisualMeshExtractor:
    """Extracts per-link GLB visual meshes from a robot GLB model.

    Each link's mesh vertices are transformed from GLB world-space (Y-up) into the
    corresponding URDF link-passive frame (Z-up) so they align with the DH-based URDF.
    """

    def __init__(  # noqa: PLR0913  # all of it is per-chain export configuration
        self,
        output_dir: str | None = None,
        model_name: str | None = None,
        dh_robot: RobotModel | None = None,
        *,
        file_prefix: str = "",
        length_divisor: float = MM_TO_M,
        include_statics: bool = False,
    ) -> None:
        self.output_dir = output_dir or "robot_export"
        self.model_name = model_name or "robot"
        self.dh_robot = dh_robot
        self.file_prefix = file_prefix
        self.length_divisor = length_divisor
        """Millimetres per URDF length unit: 1000 for metres, 1 for millimetres."""
        self.include_statics = include_statics
        """Take the robot's fixed structure too, which only its base part should."""
        self.glb: pygltflib.GLTF2 | None = None
        self.blob: bytes | None = None
        self.chains: GlbChains | None = None
        self.prefix: str | None = None
        self._link_mesh_map: dict[int, list[tuple[int, int, str]]] = {}
        self._passive_frames: list[NDArray[np.float64]] = []

    def load_model(self, glb_path: str) -> bool:
        """Load the GLB file and discover the link-to-mesh mapping."""
        try:
            loaded = pygltflib.GLTF2().load(glb_path)
            self.glb = loaded
            self.blob = loaded.binary_blob()
            self._discover_links()
            self._compute_passive_frames()
        except (OSError, ValueError):
            logger.exception("Failed to load GLB")
            return False
        else:
            return True

    def _discover_links(self) -> None:
        """Map kinematic link index to the mesh nodes carrying that link."""
        if self.glb is None:
            return
        self.chains = GlbChains(self.glb)
        self.prefix = self.chains.own_prefix(self.model_name)
        if self.prefix is None:
            logger.warning(
                "No chain in the GLB matches model %s; found %s",
                self.model_name,
                self.chains.prefixes(),
            )
            return
        self._link_mesh_map = self.chains.link_meshes(self.prefix)
        if self.include_statics:
            # Rigid relative to the robot's base, so it rides link 0.
            statics = self.chains.static_meshes(self.prefix)
            if statics:
                self._link_mesh_map.setdefault(0, []).extend(statics)
                logger.info("Including %d static structure mesh(es)", len(statics))

    def _compute_passive_frames(self) -> None:
        """Compute the world to link_k_passive accumulated DH transforms."""
        if _normalise_model(self.model_name) in _PER_LINK_GEOMETRY_MODELS:
            frames = self._per_link_frames()
            if frames is not None:
                logger.warning(_PER_LINK_GEOMETRY_WARNING, self.model_name)
                self._passive_frames = frames
                return
        self._passive_frames = self._dh_frames(self._compute_base_frame())

    def _per_link_frames(self) -> list[NDArray[np.float64]] | None:
        """DH frames, each moved to where the GLB puts that joint.

        Only the translation moves: a baking frame's rotation cancels against
        the one the URDF applies, so shifting a frame slides that link's
        geometry onto its own joint without turning it. A link with no joint
        node of its own (the base, the frame past the last joint) takes the
        nearest offset there is.
        """
        authored = self._joint_positions()
        if not authored:
            return None
        frames = self._dh_frames(np.eye(4))
        offsets = {
            index: position - frames[index][:3, 3]
            for index, position in authored.items()
            if index < len(frames)
        }
        if not offsets:
            return None
        carried = offsets[min(offsets)]
        shifted: list[NDArray[np.float64]] = []
        for index, frame in enumerate(frames):
            carried = offsets.get(index, carried)
            moved: NDArray[np.float64] = frame.copy()
            moved[:3, 3] += carried
            shifted.append(moved)
        return shifted

    def _dh_frames(self, base: NDArray[np.float64]) -> list[NDArray[np.float64]]:
        """The DH chain at zero joints, starting from *base*."""
        frames: list[NDArray[np.float64]] = [base.copy()]
        transform = base
        if self.dh_robot is not None:
            for dh in self.dh_robot.dh_parameters:
                d = dh.d / self.length_divisor
                a = dh.a / self.length_divisor
                transform = (
                    transform
                    @ _translate_z(d)
                    @ _rotate_z(dh.theta)
                    @ _translate_x(a)
                    @ _rotate_x(dh.alpha)
                )
                frames.append(transform.copy())
        return frames

    def _joint_positions(self) -> dict[int, NDArray[np.float64]]:
        """Where the GLB places each joint of the chain, in URDF length units.

        The base node comes before the chain and the flange node sorts after
        every joint; neither is a DH joint, and a model may place its flange
        where the DH chain does not (a KUKA KR6 R1820 authors it 160 mm short of
        the last DH frame), so both are left out.
        """
        if self.chains is None or self.prefix is None or self.dh_robot is None:
            return {}
        if not self.dh_robot.dh_parameters:
            return {}
        scale = MM_TO_M / self.length_divisor
        found: dict[int, NDArray[np.float64]] = {}
        for node in self.chains.chain(self.prefix):
            if not 1 <= node.index <= len(self.dh_robot.dh_parameters):
                continue
            world = _YUP_TO_ZUP @ self.chains.world_transform(node.node)
            found[node.index] = np.asarray(world[:3, 3] * scale, dtype=np.float64)
        return found

    def _residual(self, candidate: NDArray[np.float64]) -> float | None:
        """How far *candidate* is from explaining where the GLB puts the joints.

        Only positions are compared. The GLB's joint nodes do not share the DH
        frames' orientation convention -- they differ by 90 or 120 degrees, and
        by a different amount per joint -- so their rotations say nothing about
        the base frame, while their positions say everything.
        """
        authored = self._joint_positions()
        if not authored:
            return None
        frames = self._dh_frames(candidate)
        return max(
            float(np.linalg.norm(position - frames[index][:3, 3]))
            for index, position in authored.items()
            if index < len(frames)
        )

    def _measured_base_offset(self) -> NDArray[np.float64] | None:
        """One translation that puts the DH chain where the GLB authors it.

        Where the model is authored in its DH zero pose, the GLB's joints and
        the DH chain differ by one rigid offset, and that offset is what the
        link meshes have to be normalised against. Measuring it beats guessing
        at it from a single node: a model's first chain node can be a base node
        sunk below the mount plate (a Fanuc CRX puts it 245 mm down, a Yaskawa
        GP50 540 mm), which is not where the chain starts.

        Returns ``None`` when no single translation fits.
        """
        authored = self._joint_positions()
        if not authored:
            return None
        frames = self._dh_frames(np.eye(4))
        offsets = [
            position - frames[index][:3, 3]
            for index, position in authored.items()
            if index < len(frames)
        ]
        if not offsets:
            return None
        stacked: NDArray[np.float64] = np.asarray(offsets, dtype=np.float64)
        base: NDArray[np.float64] = np.eye(4)
        base[:3, 3] = np.asarray(stacked.mean(axis=0), dtype=np.float64)
        residual = self._residual(base)
        if residual is None or residual > self._tolerance():
            logger.warning(
                "%s: no single offset fits the GLB's joints (off by %.1f)",
                self.model_name,
                residual or 0.0,
            )
            return None
        return base

    def _tolerance(self) -> float:
        """Half a millimetre, in the URDF's length unit."""
        return 0.5 / self.length_divisor

    def _compute_base_frame(self) -> NDArray[np.float64]:
        """The frame the model's link geometry is authored against.

        Whatever it is, it is **not** the API mounting: the URDF already carries
        the mounting on its ``world_mount`` joint, so normalising the meshes
        against it as well applies it twice and scatters the links of a mounted
        robot. Getting it wrong shifts every link's geometry by the same amount,
        so the robot still looks whole at zero joints and comes apart as they
        move.

        Two candidates, each tested against where the GLB actually puts the
        joints. The chain root as the GLB places it comes first, because for a
        multi-part robot it carries a rotation as well -- a chain mounted on a
        carrier sits turned, and a chain that hangs along the axis it is
        turned about would let a translation-only fit look convincing while
        dropping that turn. Where the root does not explain the joints, one
        measured translation usually does: a model whose first chain node is a
        base node below the mount plate authors its chain at the origin.
        """
        authored: NDArray[np.float64] = np.eye(4)
        if self.chains is not None and self.prefix is not None:
            root = self.chains.mounting_zup(self.prefix)
            scale = MM_TO_M / self.length_divisor
            authored[:3, :3] = root[:3, :3]
            authored[:3, 3] = root[:3, 3] * scale

        residual = self._residual(authored)
        if residual is not None and residual <= self._tolerance():
            return authored

        measured = self._measured_base_offset()
        if measured is not None:
            return measured
        return authored

    def _glb_to_link_transform(self, link_idx: int, node: int) -> NDArray[np.float64]:
        """Matrix taking a mesh node's own vertices into its URDF link frame.

        Composed right to left: the node's place in the GLB tree, Y-up to Z-up,
        metres to URDF units, then into the link-passive frame. Skipping the
        node transform only works for GLBs whose nodes are all identity (Nova's
        flattened six-axis models); the multi-part ones nest link geometry under
        their joint nodes, and every link would land somewhere else.
        """
        # The GLB is in metres; scale to the URDF's length unit.
        to_units = np.diag([*([MM_TO_M / self.length_divisor] * 3), 1.0])
        placement = to_units @ _YUP_TO_ZUP @ self._node_world(node)
        if link_idx < len(self._passive_frames):
            inv_frame = np.linalg.inv(self._passive_frames[link_idx])
            return (inv_frame @ placement).astype(np.float64)
        return placement.astype(np.float64)

    def _node_world(self, node: int) -> NDArray[np.float64]:
        """The mesh node's transform relative to the GLB scene root."""
        if self.chains is None:
            return np.eye(4)
        return self.chains.world_transform(node)

    def extract_visual_meshes(self) -> dict[int, list[dict[str, str]]]:
        """Extract per-link GLB files and return mesh info dict."""
        if not self.glb or not self._link_mesh_map:
            logger.warning("No model loaded or no links found")
            return {}

        result: dict[int, list[dict[str, str]]] = {}

        for link_idx, meshes in sorted(self._link_mesh_map.items()):
            exported: list[dict[str, str]] = []
            for position, (node, mesh_idx, node_name) in enumerate(meshes):
                xform = self._glb_to_link_transform(link_idx, node)
                stem = f"{self.file_prefix}link_{link_idx}"
                if position:
                    stem = f"{stem}_{node_name}"
                glb_path = self._export_link_glb(stem, mesh_idx, xform)
                if glb_path:
                    exported.append({"file": glb_path, "node_name": node_name})
            if exported:
                result[link_idx] = exported

        return result

    def _export_link_glb(
        self,
        stem: str,
        mesh_idx: int,
        xform: NDArray[np.float64],
    ) -> str | None:
        """Decode primitives, transform vertices, write standalone GLB."""
        if self.glb is None or self.blob is None:
            return None

        mesh = self.glb.meshes[mesh_idx]
        # Normals rotate but must not scale, so drop the transform's scale.
        rot = _unit_rotation(xform)
        primitives = self._decode_all_primitives(mesh, xform, rot)

        if not primitives:
            return None

        return self._build_glb(stem, mesh.name or stem, primitives)

    def _decode_all_primitives(
        self,
        mesh: pygltflib.Mesh,
        xform: NDArray[np.float64],
        rot: NDArray[np.float64],
    ) -> list[PrimitiveData]:
        """Decode all primitives from a mesh."""
        primitives: list[PrimitiveData] = []
        for prim in mesh.primitives:
            result = self._decode_primitive(prim, xform, rot)
            if result is not None:
                primitives.append(result)
        return primitives

    def _decode_primitive(
        self,
        prim: pygltflib.Primitive,
        xform: NDArray[np.float64],
        rot: NDArray[np.float64],
    ) -> PrimitiveData | None:
        """Decode a single primitive (Draco or accessor-based)."""
        if self.glb is None or self.blob is None:
            return None

        draco_ext = (prim.extensions or {}).get(KHR_DRACO_MESH_COMPRESSION)
        if draco_ext is not None:
            vertices, normals, faces = self._decode_draco(draco_ext)
        else:
            raw_verts, raw_normals, raw_faces = self._read_prim_accessors(prim)
            if raw_verts is None or raw_faces is None:
                return None
            vertices = raw_verts.astype(np.float64)
            normals = (
                raw_normals.astype(np.float64) if raw_normals is not None else None
            )
            faces = raw_faces

        transformed_verts = _transform_vertices(vertices, xform)
        transformed_normals = _transform_normals(normals, rot)

        return PrimitiveData(
            vertices=transformed_verts,
            normals=transformed_normals,
            faces=faces,
            material_idx=prim.material,
        )

    def _decode_draco(
        self, draco_ext: dict[str, int]
    ) -> tuple[
        NDArray[np.float64],
        NDArray[np.float64] | None,
        NDArray[np.uint32],
    ]:
        """Decode Draco-compressed mesh data."""
        if self.glb is None or self.blob is None:
            msg = "GLB not loaded"
            raise ValueError(msg)

        bv = self.glb.bufferViews[draco_ext["bufferView"]]
        draco_bytes = self.blob[bv.byteOffset : bv.byteOffset + bv.byteLength]
        decoded = DracoPy.decode(draco_bytes)
        vertices: NDArray[np.float64] = np.array(
            decoded.points, dtype=np.float64
        ).reshape(-1, 3)
        faces: NDArray[np.uint32] = np.array(decoded.faces, dtype=np.uint32).reshape(
            -1, 3
        )
        normals: NDArray[np.float64] | None = None
        if hasattr(decoded, "normals") and decoded.normals is not None:
            normals = np.array(decoded.normals, dtype=np.float64).reshape(-1, 3)
        return vertices, normals, faces

    def _read_prim_accessors(
        self, prim: pygltflib.Primitive
    ) -> tuple[
        NDArray[np.float32] | None,
        NDArray[np.float32] | None,
        NDArray[np.uint32] | None,
    ]:
        """Read primitive data from accessors (non-Draco fallback)."""
        pos_acc_idx = prim.attributes.POSITION
        if pos_acc_idx is None:
            return None, None, None
        vertices: NDArray[np.float32] = self._read_accessor(pos_acc_idx, np.float32, 3)
        normals: NDArray[np.float32] | None = None
        if prim.attributes.NORMAL is not None:
            normals = self._read_accessor(prim.attributes.NORMAL, np.float32, 3)
        faces: NDArray[np.uint32] | None = None
        if prim.indices is not None:
            faces = (
                self._read_accessor_flat(prim.indices).reshape(-1, 3).astype(np.uint32)
            )
        return vertices, normals, faces

    def _read_accessor(
        self, acc_idx: int, dtype: type[np.float32], components: int
    ) -> NDArray[np.float32]:
        """Read typed data from a GLTF accessor."""
        if self.glb is None or self.blob is None:
            msg = "GLB not loaded"
            raise ValueError(msg)

        acc = self.glb.accessors[acc_idx]
        bv = self.glb.bufferViews[acc.bufferView]
        byte_offset = acc.byteOffset if acc.byteOffset is not None else 0
        start = bv.byteOffset + byte_offset
        byte_count = acc.count * components * np.dtype(dtype).itemsize
        data: NDArray[np.float32] = np.frombuffer(
            self.blob[start : start + byte_count],
            dtype=dtype,
        )
        return data.reshape(acc.count, components)

    def _read_accessor_flat(self, acc_idx: int) -> NDArray[np.uint32]:
        """Read flat data from a GLTF accessor."""
        if self.glb is None or self.blob is None:
            msg = "GLB not loaded"
            raise ValueError(msg)

        acc = self.glb.accessors[acc_idx]
        bv = self.glb.bufferViews[acc.bufferView]
        byte_offset = acc.byteOffset if acc.byteOffset is not None else 0
        start = bv.byteOffset + byte_offset
        dtype = _COMPONENT_TYPE_MAP.get(acc.componentType, np.uint32)
        byte_count = acc.count * np.dtype(dtype).itemsize
        result: NDArray[np.uint32] = (
            np
            .frombuffer(
                self.blob[start : start + byte_count],
                dtype=dtype,
            )
            .copy()
            .astype(np.uint32)
        )
        return result

    def _build_glb(
        self,
        stem: str,
        mesh_name: str,
        primitives: list[PrimitiveData],
    ) -> str:
        """Build a standalone GLB file for one link with materials."""
        if self.glb is None:
            msg = "GLB not loaded"
            raise ValueError(msg)

        used_mat_indices = _collect_material_indices(primitives)
        mat_remap = {old: new for new, old in enumerate(used_mat_indices)}

        buffer_parts, buffer_views, accessors, gltf_prims = _build_primitives_data(
            primitives, mat_remap
        )

        bin_blob = b"".join(buffer_parts)
        materials = [self.glb.materials[i] for i in used_mat_indices]

        out = pygltflib.GLTF2(
            scene=0,
            scenes=[pygltflib.Scene(nodes=[0])],
            nodes=[pygltflib.Node(mesh=0, name=mesh_name)],
            meshes=[pygltflib.Mesh(name=mesh_name, primitives=gltf_prims)],
            accessors=accessors,
            bufferViews=buffer_views,
            buffers=[pygltflib.Buffer(byteLength=len(bin_blob))],
            materials=materials,
        )
        out.set_binary_blob(bin_blob)

        out_dir = Path(self.output_dir) / "visual"
        out_dir.mkdir(parents=True, exist_ok=True)
        filepath = out_dir / f"{stem}.glb"
        out.save(str(filepath))

        # Also export OBJ+MTL for tools that don't support GLB (RViz, MuJoCo, PyBullet)
        self._export_link_obj(stem, mesh_name, primitives, out_dir)

        return str(filepath)

    def _export_link_obj(
        self,
        stem: str,
        mesh_name: str,
        primitives: list[PrimitiveData],
        out_dir: Path,
    ) -> None:
        """Write OBJ + MTL files for one link with material colors."""
        if self.glb is None or not primitives:
            return

        mtl_name = f"{stem}.mtl"
        mat_entries, mat_idx_to_name = _collect_obj_materials(
            primitives, self.glb.materials
        )

        _write_mtl(out_dir / mtl_name, mat_entries)
        _write_obj(
            out_dir / f"{stem}.obj",
            mesh_name,
            mtl_name,
            primitives,
            mat_idx_to_name,
        )


# ---------------------------------------------------------------------------
# Pure helper functions
# ---------------------------------------------------------------------------


def _unit_rotation(xform: NDArray[np.float64]) -> NDArray[np.float64]:
    """The transform's rotation with any uniform scale divided out."""
    rotation: NDArray[np.float64] = np.asarray(xform[:3, :3], dtype=np.float64)
    squared: NDArray[np.float64] = rotation * rotation
    sums: NDArray[np.float64] = np.asarray(squared.sum(axis=0), dtype=np.float64)
    lengths: NDArray[np.float64] = np.sqrt(sums)
    safe: NDArray[np.float64] = np.where(lengths > 0.0, lengths, 1.0)
    return rotation / safe


def _transform_vertices(
    vertices: NDArray[np.float64],
    xform: NDArray[np.float64],
) -> NDArray[np.float32]:
    """Apply a 4x4 homogeneous transform to vertex positions."""
    ones_col: NDArray[np.float64] = np.ones((len(vertices), 1))
    vh: NDArray[np.float64] = np.hstack([vertices, ones_col])
    transformed: NDArray[np.float64] = (xform @ vh.T).T[:, :3]
    return transformed.astype(np.float32)


def _transform_normals(
    normals: NDArray[np.float64] | None,
    rot: NDArray[np.float64],
) -> NDArray[np.float32] | None:
    """Apply a 3x3 rotation to normal vectors."""
    if normals is None:
        return None
    raw_result: NDArray[np.float64] = (rot @ normals.T).T
    return raw_result.astype(np.float32)


def _collect_material_indices(primitives: list[PrimitiveData]) -> list[int]:
    """Collect unique material indices from primitives, preserving order."""
    seen: dict[int, None] = {}
    for p in primitives:
        if p.material_idx is not None:
            seen.setdefault(p.material_idx, None)
    return list(seen)


class _GlbBufferBuilder:
    """Accumulates GLB buffer parts, views, and accessors."""

    def __init__(self) -> None:
        self.parts: list[bytes] = []
        self.views: list[pygltflib.BufferView] = []
        self.accessors: list[pygltflib.Accessor] = []
        self._offset: int = 0

    def add(self, entry: BufferEntry) -> int:
        """Append a buffer and return the new accessor index."""
        bv_idx = len(self.views)
        self.views.append(
            pygltflib.BufferView(
                buffer=0,
                byteOffset=self._offset,
                byteLength=len(entry.data),
                target=entry.target,
            )
        )
        acc_idx = len(self.accessors)
        if entry.bounds is not None:
            self.accessors.append(
                pygltflib.Accessor(
                    bufferView=bv_idx,
                    componentType=entry.component_type,
                    count=entry.count,
                    type=entry.accessor_type,
                    max=entry.bounds[0],
                    min=entry.bounds[1],
                )
            )
        else:
            self.accessors.append(
                pygltflib.Accessor(
                    bufferView=bv_idx,
                    componentType=entry.component_type,
                    count=entry.count,
                    type=entry.accessor_type,
                )
            )
        self.parts.append(entry.data)
        self._offset += len(entry.data)
        return acc_idx


def _build_primitives_data(
    primitives: list[PrimitiveData],
    mat_remap: dict[int, int],
) -> tuple[
    list[bytes],
    list[pygltflib.BufferView],
    list[pygltflib.Accessor],
    list[pygltflib.Primitive],
]:
    """Build all GLB buffer data from primitives."""
    builder = _GlbBufferBuilder()
    gltf_prims: list[pygltflib.Primitive] = []

    for p in primitives:
        acc_pos = builder.add(
            BufferEntry(
                data=p.vertices.tobytes(),
                component_type=pygltflib.FLOAT,
                count=len(p.vertices),
                accessor_type=pygltflib.VEC3,
                target=pygltflib.ARRAY_BUFFER,
                bounds=_compute_bounds(p.vertices),
            )
        )

        acc_norm: int | None = None
        if p.normals is not None and len(p.normals) == len(p.vertices):
            acc_norm = builder.add(
                BufferEntry(
                    data=p.normals.tobytes(),
                    component_type=pygltflib.FLOAT,
                    count=len(p.normals),
                    accessor_type=pygltflib.VEC3,
                    target=pygltflib.ARRAY_BUFFER,
                )
            )

        acc_idx = builder.add(
            BufferEntry(
                data=p.faces.flatten().tobytes(),
                component_type=pygltflib.UNSIGNED_INT,
                count=p.faces.size,
                accessor_type=pygltflib.SCALAR,
                target=pygltflib.ELEMENT_ARRAY_BUFFER,
            )
        )

        attrs = pygltflib.Attributes(POSITION=acc_pos)
        if acc_norm is not None:
            attrs.NORMAL = acc_norm

        gltf_prims.append(
            pygltflib.Primitive(
                attributes=attrs,
                indices=acc_idx,
                material=mat_remap.get(p.material_idx)
                if p.material_idx is not None
                else None,
            )
        )

    return builder.parts, builder.views, builder.accessors, gltf_prims


def _compute_bounds(
    verts: NDArray[np.float32],
) -> tuple[list[float], list[float]]:
    """Compute min/max bounds for a vertex array."""
    max_arr: NDArray[np.float32] = np.asarray(verts.max(axis=0), dtype=np.float32)
    min_arr: NDArray[np.float32] = np.asarray(verts.min(axis=0), dtype=np.float32)
    return (
        [float(max_arr.item(i)) for i in range(len(max_arr))],
        [float(min_arr.item(i)) for i in range(len(min_arr))],
    )


# ---------------------------------------------------------------------------
# OBJ + MTL export helpers
# ---------------------------------------------------------------------------

_ObjMaterial = tuple[str, tuple[float, float, float], float, float]
"""(name, kd_rgb, metallic, roughness)."""


def _extract_pbr_color(
    mat: pygltflib.Material,
) -> tuple[tuple[float, float, float], float, float]:
    """Extract diffuse color, metallic, and roughness from a GLB material."""
    pbr = mat.pbrMetallicRoughness
    if pbr and pbr.baseColorFactor:
        kd = (pbr.baseColorFactor[0], pbr.baseColorFactor[1], pbr.baseColorFactor[2])
    else:
        kd = (0.8, 0.8, 0.8)
    metallic = pbr.metallicFactor if pbr else 0.0
    roughness = pbr.roughnessFactor if pbr else 1.0
    return kd, metallic, roughness


def _collect_obj_materials(
    primitives: list[PrimitiveData],
    glb_materials: list[pygltflib.Material],
) -> tuple[list[_ObjMaterial], dict[int | None, str]]:
    """Build unique material list from primitives."""
    entries: list[_ObjMaterial] = []
    idx_to_name: dict[int | None, str] = {}
    for p in primitives:
        if p.material_idx in idx_to_name:
            continue
        if p.material_idx is not None and p.material_idx < len(glb_materials):
            glb_mat = glb_materials[p.material_idx]
            name = (glb_mat.name or f"material_{p.material_idx}").replace(" ", "_")
            kd, metallic, roughness = _extract_pbr_color(glb_mat)
        else:
            name = f"default_{len(entries)}"
            kd, metallic, roughness = (0.8, 0.8, 0.8), 0.0, 1.0
        idx_to_name[p.material_idx] = name
        entries.append((name, kd, metallic, roughness))
    return entries, idx_to_name


def _write_mtl(mtl_path: Path, mat_entries: list[_ObjMaterial]) -> None:
    """Write a Wavefront MTL file."""
    with mtl_path.open("w", encoding="utf-8") as mtl:
        for name, kd, metallic, roughness in mat_entries:
            ks_val = metallic * 0.8
            ns = (1.0 - roughness) * 200.0
            mtl.write(f"newmtl {name}\n")
            mtl.write(f"Kd {kd[0]:.6f} {kd[1]:.6f} {kd[2]:.6f}\n")
            mtl.write(f"Ks {ks_val:.6f} {ks_val:.6f} {ks_val:.6f}\n")
            mtl.write(f"Ns {ns:.1f}\n")
            mtl.write("d 1.0\n")
            mtl.write("illum 2\n\n")


def _write_obj(
    obj_path: Path,
    mesh_name: str,
    mtl_name: str,
    primitives: list[PrimitiveData],
    mat_idx_to_name: dict[int | None, str],
) -> None:
    """Write a Wavefront OBJ file with material references."""
    with obj_path.open("w", encoding="utf-8") as obj:
        obj.write(f"# {mesh_name}\n")
        obj.write(f"mtllib {mtl_name}\n\n")

        vertex_offset = 0
        for p in primitives:
            mat_name = mat_idx_to_name.get(p.material_idx, "default")
            obj.write(f"usemtl {mat_name}\n")
            _write_obj_primitive(obj, p, vertex_offset)
            vertex_offset += len(p.vertices)


def _write_obj_primitive(
    obj: IO[str],
    p: PrimitiveData,
    vertex_offset: int,
) -> None:
    """Write vertices, normals, and faces for one primitive."""
    verts_list = cast("list[list[float]]", p.vertices.tolist())
    for v in verts_list:
        obj.write(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")

    has_normals = p.normals is not None and len(p.normals) == len(p.vertices)
    if has_normals and p.normals is not None:
        norms_list = cast("list[list[float]]", p.normals.tolist())
        for n in norms_list:
            obj.write(f"vn {n[0]:.6f} {n[1]:.6f} {n[2]:.6f}\n")

    faces_list: list[list[int]] = p.faces.reshape(-1, 3).tolist()
    for f in faces_list:
        i0 = f[0] + 1 + vertex_offset
        i1 = f[1] + 1 + vertex_offset
        i2 = f[2] + 1 + vertex_offset
        if has_normals:
            obj.write(f"f {i0}//{i0} {i1}//{i1} {i2}//{i2}\n")
        else:
            obj.write(f"f {i0} {i1} {i2}\n")
