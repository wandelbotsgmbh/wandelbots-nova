"""Shared constants for the nova2urdf package."""

import math

MM_TO_M: float = 1000.0
"""Conversion factor: divide millimetres by this to get metres."""

DEFAULT_JOINT_LIMIT: float = math.pi
"""Default joint rotation limit in radians (±π)."""

DEFAULT_VELOCITY: float = 1.0
"""Default joint velocity limit (rad/s)."""

DEFAULT_EFFORT: float = 100.0
"""Default joint effort limit (N·m)."""

# GLB / glTF component type IDs
COMPONENT_UINT8: int = 5121
COMPONENT_UINT16: int = 5123
COMPONENT_UINT32: int = 5125

# Draco extension name
KHR_DRACO_MESH_COMPRESSION: str = "KHR_draco_mesh_compression"

# Joint naming patterns in GLB node tree
JOINT_ROOT_MARKER: str = "_J00"
JOINT_MARKER: str = "_J0"
FLANGE_MARKER: str = "_FLG"
BASE_LINK_NAME: str = "link_0"

# Collision mesh constraints
MIN_CONVEX_HULL_POINTS: int = 4
