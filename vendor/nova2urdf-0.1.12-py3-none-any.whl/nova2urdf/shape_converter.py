"""Unified shape-to-mesh conversion for collision primitives.

Handles sphere, box, cylinder, capsule, and convex_hull shapes. Input
dimensions are in millimetres; output meshes are in whatever unit the URDF
being written uses, which is what ``length_divisor`` says.
"""

import logging

import numpy as np
import trimesh

from .constants import MIN_CONVEX_HULL_POINTS, MM_TO_M
from .utils import to_float

logger = logging.getLogger(__name__)


def shape_to_mesh(
    shape: dict[str, object],
    margin: float = 0.0,
    length_divisor: float = MM_TO_M,
) -> trimesh.Trimesh | None:
    """Convert a shape dict to a trimesh object.

    Args:
        shape: Shape descriptor with ``shape_type`` and geometry fields.
            All lengths are in **millimetres**.
        margin: Extra padding added to each dimension (mm).
        length_divisor: Millimetres per unit of the URDF being written: 1000 for
            a metre URDF, 1 for a millimetre one. Writing metres into a
            millimetre URDF makes every collider a thousandth of its size.

    Returns:
        A :class:`trimesh.Trimesh` in the URDF's length unit, or ``None`` for
        unsupported shapes.
    """
    shape_type = str(shape.get("shape_type", ""))

    if shape_type == "convex_hull":
        return _convex_hull_to_mesh(shape, length_divisor)
    if shape_type == "sphere":
        r = (to_float(shape.get("radius", 0)) + margin) / length_divisor
        return trimesh.primitives.Sphere(radius=r).to_mesh()  # pyright: ignore[reportUnknownMemberType]
    if shape_type == "box":
        sx = (to_float(shape.get("size_x", 0)) + margin) / length_divisor
        sy = (to_float(shape.get("size_y", 0)) + margin) / length_divisor
        sz = (to_float(shape.get("size_z", 0)) + margin) / length_divisor
        return trimesh.primitives.Box(extents=(sx, sy, sz)).to_mesh()  # pyright: ignore[reportUnknownMemberType]
    if shape_type == "cylinder":
        r = (to_float(shape.get("radius", 0)) + margin) / length_divisor
        h = (to_float(shape.get("height", 0)) + margin) / length_divisor
        return trimesh.primitives.Cylinder(radius=r, height=h).to_mesh()  # pyright: ignore[reportUnknownMemberType]
    if shape_type == "capsule":
        r = (to_float(shape.get("radius", 0)) + margin) / length_divisor
        h = to_float(shape.get("cylinder_height", 0)) / length_divisor
        return trimesh.primitives.Capsule(radius=r, height=h).to_mesh()  # pyright: ignore[reportUnknownMemberType]

    logger.warning("Unsupported shape type: %s", shape_type)
    return None


def _convex_hull_to_mesh(
    shape: dict[str, object], length_divisor: float = MM_TO_M
) -> trimesh.Trimesh | None:
    """Convert a convex hull shape to a trimesh."""
    if "vertices" not in shape:
        return None
    try:
        points = np.array(shape["vertices"]) / length_divisor
        if len(points) < MIN_CONVEX_HULL_POINTS:
            logger.warning("Too few points for convex hull")
            return None
        result = trimesh.convex.convex_hull(points)  # pyright: ignore[reportUnknownMemberType,reportUnknownVariableType]
        if isinstance(result, trimesh.Trimesh):
            return result
    except (ValueError, IndexError):
        logger.exception("Error creating convex hull")
    return None
