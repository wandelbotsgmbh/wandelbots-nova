"""Command-line interface for nova2urdf.

Usage:
    nova2urdf convert <model>                     Convert a specific robot model to URDF
    nova2urdf convert --all                       Convert all available robot models
    nova2urdf list                                List available robot models
    nova2urdf validate <path>                     Validate URDF file(s)
    nova2urdf export-controller <ctrl> [--tcp X]  Export URDF from an existing controller
    nova2urdf completions <shell>                 Print shell completion script

Environment variables:
    NOVA_API_URL          Nova instance URL (required)
    NOVA_ACCESS_TOKEN     Bearer token for authentication (optional)
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
from pathlib import Path
import sys
from typing import cast
import xml.etree.ElementTree as ET  # noqa: S405

import httpx

from .api_client import (
    fetch_config_ids,
    fetch_existing_controllers,
    fetch_model_ids,
    get_headers,
    load_env,
)
from .constants import MM_TO_M
from .export_robot_urdf import (
    export_controller,
    export_robot,
)

__version__ = "0.1.0"

logger = logging.getLogger(__name__)

_MAX_CONCURRENCY = 4
_MAX_RETRIES = 2
_CLIENT_TIMEOUT = 180
_DEFAULT_OUTPUT_DIR = "robot_exports"


# ── Shell completions ─────────────────────────────────────────

_BASH_COMPLETION = r"""
# nova2urdf bash completion
_nova2urdf() {
    local cur prev commands
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    commands="convert list validate export-controller completions"

    if [ "$COMP_CWORD" -eq 1 ] || { [ "$COMP_CWORD" -eq 3 ] && [[ "${COMP_WORDS[1]}" == --* ]]; }; then
        COMPREPLY=( $(compgen -W "$commands" -- "$cur") )
        return 0
    fi

    case "$prev" in
        convert)
            COMPREPLY=( $(compgen -W "--all $(nova2urdf list 2>/dev/null | grep '^ ' | sed 's/^ *- //')" -- "$cur") )
            ;;
        completions)
            COMPREPLY=( $(compgen -W "bash zsh fish" -- "$cur") )
            ;;
        --nova-url|-o|--output-dir|--tcp)
            ;;
        *)
            COMPREPLY=( $(compgen -W "--nova-url -o --output-dir -y --yes --quiet --verbose" -- "$cur") )
            ;;
    esac
    return 0
}
complete -F _nova2urdf nova2urdf
""".strip()

_ZSH_COMPLETION = r"""
#compdef nova2urdf
_nova2urdf() {
    local -a commands
    commands=(
        'convert:Convert robot model(s) to URDF'
        'list:List available robot models'
        'validate:Validate URDF file(s)'
        'export-controller:Export URDF from an existing controller'
        'completions:Print shell completion script'
    )
    _arguments \
        '--version[Show version]' \
        '--nova-url[Nova instance URL]:url' \
        '(-o --output-dir)'{-o,--output-dir}'[Output directory]:dir:_directories' \
        '(-q --quiet)'{-q,--quiet}'[Suppress info logging]' \
        '(-v --verbose)'{-v,--verbose}'[Enable debug logging]' \
        '1:command:->cmd' \
        '*::arg:->args'
    case "$state" in
        cmd) _describe 'command' commands ;;
        args)
            case "$words[1]" in
                completions) _values 'shell' bash zsh fish ;;
            esac ;;
    esac
}
_nova2urdf "$@"
""".strip()

_FISH_COMPLETION = r"""
# nova2urdf fish completion
complete -c nova2urdf -n __fish_use_subcommand -a convert -d "Convert robot model(s) to URDF"
complete -c nova2urdf -n __fish_use_subcommand -a list -d "List available robot models"
complete -c nova2urdf -n __fish_use_subcommand -a validate -d "Validate URDF file(s)"
complete -c nova2urdf -n __fish_use_subcommand -a export-controller -d "Export from existing controller"
complete -c nova2urdf -n __fish_use_subcommand -a completions -d "Print shell completion script"
complete -c nova2urdf -l nova-url -d "Nova instance URL"
complete -c nova2urdf -s o -l output-dir -d "Output directory"
complete -c nova2urdf -s q -l quiet -d "Suppress info logging"
complete -c nova2urdf -s v -l verbose -d "Enable debug logging"
complete -c nova2urdf -n "__fish_seen_subcommand_from convert" -l all -d "Convert all models"
complete -c nova2urdf -n "__fish_seen_subcommand_from convert" -s y -l yes -d "Skip confirmation"
complete -c nova2urdf -n "__fish_seen_subcommand_from completions" -a "bash zsh fish"
""".strip()

_COMPLETION_SCRIPTS = {
    "bash": _BASH_COMPLETION,
    "zsh": _ZSH_COMPLETION,
    "fish": _FISH_COMPLETION,
}


# ── Helpers ───────────────────────────────────────────────────


def _resolve_model_id(model_name: str, model_ids: list[str]) -> str | None:
    """Resolve a user-provided name to an exact model ID.

    Accepts the exact ID (``FANUC_CRX25iA``), a case-insensitive match,
    or a partial suffix match (``crx25ia``).
    """
    lower = model_name.lower()
    for mid in model_ids:
        if mid.lower() == lower:
            return mid
    # Try suffix match after manufacturer prefix (e.g. "crx25ia" -> "FANUC_CRX25iA")
    for mid in model_ids:
        parts = mid.split("_", maxsplit=1)
        if len(parts) == 2 and parts[1].lower() == lower:  # noqa: PLR2004
            return mid
    # Fuzzy: strip underscores/hyphens for comparison
    stripped = lower.replace("_", "").replace("-", "")
    for mid in model_ids:
        if mid.lower().replace("_", "").replace("-", "") == stripped:
            return mid
        parts = mid.split("_", maxsplit=1)
        if (
            len(parts) == 2  # noqa: PLR2004
            and parts[1].lower().replace("_", "").replace("-", "") == stripped
        ):
            return mid
    return None


async def _list_models() -> None:
    """Print all available robot models grouped by manufacturer."""
    headers = get_headers()
    async with httpx.AsyncClient(headers=headers, timeout=30) as client:
        model_ids = await fetch_model_ids(client)

    robots_by_manufacturer: dict[str, list[str]] = {}
    for mid in model_ids:
        parts = mid.split("_", maxsplit=1)
        if len(parts) == 2:  # noqa: PLR2004
            manufacturer, model = parts
        else:
            manufacturer, model = "OTHER", mid
        robots_by_manufacturer.setdefault(manufacturer, []).append(model)

    print(f"Available robot models ({len(model_ids)} total):")  # noqa: T201
    for manufacturer, models in sorted(robots_by_manufacturer.items()):
        print(f"\n{manufacturer}:")  # noqa: T201
        for robot in sorted(models):
            print(f"  - {robot}")  # noqa: T201


def _confirm_existing_controllers(controllers: list[str]) -> bool:
    """Warn about existing controllers and ask for confirmation.

    Returns True if the user confirms or there are no controllers.
    """
    if not controllers:
        return True

    print(  # noqa: T201
        f"\n⚠️  Warning: Nova instance has {len(controllers)} existing controller(s):"
    )
    for name in controllers:
        print(f"   • {name}")  # noqa: T201
    print(  # noqa: T201
        "\nThe 'convert' command creates temporary virtual controllers "
        + "and deletes them after export.\n"
        + "Existing controllers may conflict with this process."
    )

    try:
        answer = input("\nContinue anyway? [y/N] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()  # noqa: T201
        return False
    return answer in {"y", "yes"}


# ── Validate ──────────────────────────────────────────────────


def _validate_joints(root: ET.Element, links: set[str | None]) -> list[str]:
    """Validate joint references in a URDF root element."""
    errors: list[str] = []
    for joint in root.findall("joint"):
        jname = joint.get("name", "unnamed")
        parent = joint.find("parent")
        child = joint.find("child")
        if parent is None or child is None:
            errors.append(f"Joint '{jname}' missing parent or child element")
            continue
        if parent.get("link", "") not in links:
            errors.append(
                f"Joint '{jname}' references unknown parent link '{parent.get('link', '')}'"
            )
        if child.get("link", "") not in links:
            errors.append(
                f"Joint '{jname}' references unknown child link '{child.get('link', '')}'"
            )
    return errors


def _validate_urdf(path: Path) -> list[str]:
    """Validate a single URDF file. Returns list of error messages (empty = OK)."""
    try:
        tree = ET.parse(path)  # noqa: S314
    except ET.ParseError as exc:
        return [f"XML parse error: {exc}"]

    root = tree.getroot()
    if root.tag != "robot":
        return [f"Root element is <{root.tag}>, expected <robot>"]

    errors: list[str] = []
    if not root.get("name", ""):
        errors.append("Robot element missing 'name' attribute")

    links = {link.get("name") for link in root.findall("link")}
    if not links:
        errors.append("No <link> elements found")
    if not root.findall("joint"):
        errors.append("No <joint> elements found")

    errors.extend(_validate_joints(root, links))

    # Check mesh files exist (relative to URDF location)
    urdf_dir = path.parent
    for mesh in root.iter("mesh"):
        filename = mesh.get("filename", "")
        if filename and not (urdf_dir / filename).exists():
            errors.append(f"Missing mesh file: {filename}")

    return errors


def _run_validate(paths: list[str]) -> bool:
    """Validate one or more URDF files/directories."""
    urdf_files: list[Path] = []
    for p in paths:
        path = Path(p)
        if path.is_file() and path.suffix == ".urdf":
            urdf_files.append(path)
        elif path.is_dir():
            urdf_files.extend(sorted(path.rglob("*.urdf")))
        else:
            logger.error("Not a URDF file or directory: %s", p)
            return False

    if not urdf_files:
        logger.error("No URDF files found in: %s", ", ".join(paths))
        return False

    total_errors = 0
    failed_count = 0
    for urdf in urdf_files:
        errors = _validate_urdf(urdf)
        if errors:
            print(f"❌ {urdf}")  # noqa: T201
            for err in errors:
                print(f"   {err}")  # noqa: T201
            total_errors += len(errors)
            failed_count += 1
        else:
            print(f"✅ {urdf}")  # noqa: T201

    passed = len(urdf_files) - failed_count
    msg = (
        f"\nValidated {len(urdf_files)} file(s): {passed} passed, {failed_count} failed"
    )
    print(msg)  # noqa: T201
    return total_errors == 0


# ── Convert commands ──────────────────────────────────────────


async def _convert_one(
    model_name: str, *, skip_check: bool = False, output_dir: str | None = None
) -> bool:
    """Convert a single robot model to URDF."""
    headers = get_headers()
    async with httpx.AsyncClient(headers=headers, timeout=_CLIENT_TIMEOUT) as client:
        if not skip_check:
            controllers = await fetch_existing_controllers(client)
            if not _confirm_existing_controllers(controllers):
                logger.info("Aborted by user.")
                return False

        model_ids = await fetch_model_ids(client)
        model_id = _resolve_model_id(model_name, model_ids)
        if model_id is None:
            logger.error(
                "Robot model '%s' not found. Run 'nova2urdf list' to see available models.",
                model_name,
            )
            return False

        logger.info("Resolved '%s' -> %s", model_name, model_id)
        result = await export_robot(client, model_id, output_dir=output_dir)
        if result:
            logger.info("Success! URDF at: %s", result)
            return True
        logger.error("Failed to export %s", model_name)
        return False


async def _export_controller_cmd(
    controller_name: str,
    tcp_name: str | None,
    output_dir: str | None = None,
    units: str = "m",
) -> bool:
    """Export URDF from an existing Nova controller."""
    headers = get_headers()
    async with httpx.AsyncClient(headers=headers, timeout=_CLIENT_TIMEOUT) as client:
        result = await export_controller(
            client,
            controller_name,
            tcp_name=tcp_name,
            output_dir=output_dir,
            length_divisor=MM_TO_M if units == "m" else 1.0,
        )
        if result:
            logger.info("Success! URDF at: %s", result)
            return True
        logger.error("Failed to export controller %s", controller_name)
        return False


async def _export_with_retry(
    client: httpx.AsyncClient,
    mid: str,
    config_ids: list[str],
    output_dir: str | None,
) -> str | None:
    """Export a single model with retries. Returns URDF path or None."""
    last_err: BaseException | None = None
    for attempt in range(_MAX_RETRIES):
        try:
            result = await export_robot(
                client, mid, config_ids=config_ids, output_dir=output_dir
            )
            if result:
                return result
        except Exception as exc:  # noqa: BLE001
            last_err = exc
            if attempt < _MAX_RETRIES - 1:
                logger.debug(
                    "Retry %d/%d for %s: %s", attempt + 1, _MAX_RETRIES, mid, exc
                )
                await asyncio.sleep(2)
    if last_err:
        logger.debug("All retries failed for %s: %s", mid, last_err)
    return None


async def _convert_all(
    *, skip_check: bool = False, output_dir: str | None = None
) -> bool:
    """Convert all available robot models to URDF concurrently."""
    headers = get_headers()
    async with httpx.AsyncClient(headers=headers, timeout=_CLIENT_TIMEOUT) as client:
        if not skip_check:
            controllers = await fetch_existing_controllers(client)
            if not _confirm_existing_controllers(controllers):
                logger.info("Aborted by user.")
                return False

        model_ids, config_ids = await asyncio.gather(
            fetch_model_ids(client), fetch_config_ids(client)
        )
        total = len(model_ids)
        logger.info("Found %d models to export", total)

        semaphore = asyncio.Semaphore(_MAX_CONCURRENCY)
        completed = 0
        successful = 0
        failed_models: list[str] = []

        async def _bounded_export(mid: str) -> None:
            nonlocal completed, successful
            async with semaphore:
                result = await _export_with_retry(client, mid, config_ids, output_dir)
            completed += 1
            if result:
                successful += 1
                print(f"  [{completed}/{total}] ✅ {mid}")  # noqa: T201
            else:
                failed_models.append(mid)
                print(f"  [{completed}/{total}] ❌ {mid}")  # noqa: T201

        await asyncio.gather(*[_bounded_export(mid) for mid in model_ids])

        print(  # noqa: T201
            f"\nExported {successful}/{total} models successfully "
            + f"({len(failed_models)} failed)."
        )
        if failed_models:
            print("Failed models:")  # noqa: T201
            for m in sorted(failed_models):
                print(f"  - {m}")  # noqa: T201

        return len(failed_models) == 0


# ── CLI entry point ───────────────────────────────────────────


def _check_nova_url() -> bool:
    """Check that a Nova URL is configured. Returns True if OK."""
    url = os.environ.get("NOVA_API_URL") or os.environ.get("NOVA_API")
    if not url:
        logger.error(
            "No Nova instance URL configured. Set NOVA_API_URL or use --nova-url.\n"
            + "  Example: nova2urdf --nova-url http://172.31.1.100 list"
        )
        return False
    return True


def _build_parser() -> argparse.ArgumentParser:
    """Build the argument parser."""
    parser = argparse.ArgumentParser(
        prog="nova2urdf",
        description="Export robot models from Wandelbots Nova to URDF format.",
    )
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )
    parser.add_argument(
        "--nova-url", help="Nova instance URL (overrides NOVA_API_URL env var)"
    )
    parser.add_argument(
        "-o",
        "--output-dir",
        default=_DEFAULT_OUTPUT_DIR,
        help=f"Output directory for exported models (default: {_DEFAULT_OUTPUT_DIR})",
    )
    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Suppress informational output (errors only)",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Enable debug logging"
    )
    subparsers = parser.add_subparsers(dest="command")

    # --- convert ---
    convert_parser = subparsers.add_parser(
        "convert", help="Convert robot model(s) to URDF"
    )
    group = convert_parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "model",
        nargs="?",
        default=None,
        help="Model name (e.g. crx25ia, FANUC_CRX25iA)",
    )
    group.add_argument(
        "--all", action="store_true", dest="convert_all", help="Convert all models"
    )
    convert_parser.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Skip confirmation when existing controllers are found",
    )

    # --- list ---
    subparsers.add_parser("list", help="List available robot models")

    # --- validate ---
    validate_parser = subparsers.add_parser(
        "validate", help="Validate URDF file(s) or directories"
    )
    validate_parser.add_argument(
        "paths", nargs="+", help="URDF file(s) or directories to validate"
    )

    # --- export-controller ---
    ctrl_parser = subparsers.add_parser(
        "export-controller", help="Export URDF from an existing Nova controller"
    )
    ctrl_parser.add_argument("controller", help="Controller name as configured in Nova")
    ctrl_parser.add_argument(
        "--tcp",
        default=None,
        help="TCP name to use for the tool0 frame (default: flange origin)",
    )
    ctrl_parser.add_argument(
        "--units",
        choices=["m", "mm"],
        default="m",
        help="URDF length unit; metres is what standard consumers expect (default: m)",
    )

    # --- completions ---
    comp_parser = subparsers.add_parser(
        "completions", help="Print shell completion script"
    )
    comp_parser.add_argument(
        "shell", choices=["bash", "zsh", "fish"], help="Shell type"
    )

    return parser


def _run_command(args: argparse.Namespace, output_dir: str) -> int:
    """Dispatch to the appropriate command handler."""
    command = cast("str", args.command)

    if command == "validate":
        paths = cast("list[str]", args.paths)
        return 0 if _run_validate(paths) else 1

    if command == "completions":
        shell = cast("str", args.shell)
        print(_COMPLETION_SCRIPTS[shell])  # noqa: T201
        return 0

    # All remaining commands need Nova
    if not _check_nova_url():
        return 1

    if command == "list":
        asyncio.run(_list_models())
        return 0

    if command == "convert":
        skip = bool(getattr(args, "yes", False))
        if bool(getattr(args, "convert_all", False)):
            ok = asyncio.run(_convert_all(skip_check=skip, output_dir=output_dir))
        else:
            model = cast("str", args.model)
            ok = asyncio.run(
                _convert_one(model, skip_check=skip, output_dir=output_dir)
            )
    elif command == "export-controller":
        controller = cast("str", args.controller)
        tcp = cast("str | None", args.tcp)
        ok = asyncio.run(
            _export_controller_cmd(
                controller, tcp, output_dir=output_dir, units=cast("str", args.units)
            )
        )
    else:
        return 1

    return 0 if ok else 1


def main() -> int:
    """CLI entry point."""
    load_env()
    parser = _build_parser()
    args = parser.parse_args()

    # Configure logging level
    if bool(getattr(args, "verbose", False)):
        log_level = logging.DEBUG
    elif bool(getattr(args, "quiet", False)):
        log_level = logging.WARNING
    else:
        log_level = logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    nova_url = cast("str | None", getattr(args, "nova_url", None))
    if nova_url:
        os.environ["NOVA_API_URL"] = nova_url

    command = cast("str | None", args.command)
    if not command:
        parser.print_help()
        return 1

    output_dir = cast("str", getattr(args, "output_dir", _DEFAULT_OUTPUT_DIR))
    return _run_command(args, output_dir)


if __name__ == "__main__":
    sys.exit(main())
