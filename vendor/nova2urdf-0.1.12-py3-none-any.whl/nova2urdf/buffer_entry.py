"""Typed containers for GLB buffer building."""

from dataclasses import dataclass


@dataclass(frozen=True)
class BufferEntry:
    """Parameters for a single buffer to add to a GLB file."""

    data: bytes
    component_type: int
    count: int
    accessor_type: str
    target: int
    bounds: tuple[list[float], list[float]] | None = None
