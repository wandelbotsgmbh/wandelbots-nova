"""Shared utility functions for the nova2urdf package."""


def to_float(value: object, default: float = 0.0) -> float:
    """Safely convert an object to float."""
    if isinstance(value, int | float):
        return float(value)
    return default
