"""Nova v2 API client helpers.

Centralises environment configuration, authentication headers, and
all HTTP interactions with the Nova REST API so that the orchestration
layer (``export_robot_urdf``) stays focused on business logic.
"""

from __future__ import annotations

import asyncio
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
import logging
import os
from pathlib import Path
import secrets
import time
from typing import TYPE_CHECKING, cast

import httpx

if TYPE_CHECKING:
    from collections.abc import Iterator

logger = logging.getLogger(__name__)

_HTTP_OK = 200
_CONTROLLER_TIMEOUT = 90.0


# ── Environment / config ─────────────────────────────────────


def load_env() -> None:
    """Load .env file if present.  Checks cwd first, then package directory."""
    candidates = [Path.cwd() / ".env", Path(__file__).resolve().parent / ".env"]
    env_path = next((p for p in candidates if p.exists()), None)
    if env_path is None:
        return
    with env_path.open(encoding="utf-8") as f:
        for raw_line in f:
            line = raw_line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, value = line.partition("=")
                value = value.strip().strip('"').strip("'")
                os.environ.setdefault(key.strip(), value)


@dataclass(frozen=True)
class _Target:
    """The Nova instance one export talks to. Unset fields fall back to the environment."""

    url: str | None = None
    cell: str | None = None


_TARGET: ContextVar[_Target | None] = ContextVar("nova_target", default=None)


@contextmanager
def nova_target(url: str | None = None, cell: str | None = None) -> Iterator[None]:
    """Point every Nova call made inside at one instance.

    Without this, the target comes from the process environment, so a single
    process can only ever talk to one Nova. The target is scoped to the calling
    task, which is what makes it safe to export from two instances at once:
    tasks started inside inherit it, siblings are unaffected.

    Credentials stay on the ``httpx.AsyncClient`` the caller passes in.
    """
    if url is None and cell is None:
        yield
        return
    current = _TARGET.get()
    token = _TARGET.set(
        _Target(
            url=url or (current.url if current else None),
            cell=cell or (current.cell if current else None),
        )
    )
    try:
        yield
    finally:
        _TARGET.reset(token)


def get_api_base() -> str:
    """Return the API base URL of the current target, else the environment."""
    target = _TARGET.get()
    nova_api = (target.url if target and target.url else None) or (
        os.environ.get("NOVA_API_URL") or os.environ.get("NOVA_API", "")
    )
    if not nova_api:
        msg = (
            "No Nova instance URL configured. Pass nova_url=, wrap the call in "
            "nova_target(), set NOVA_API_URL, or use --nova-url."
        )
        raise RuntimeError(msg)
    return nova_api.rstrip("/") + "/api/v2"


def get_cell() -> str:
    """Return the cell of the current target, else the environment."""
    target = _TARGET.get()
    if target and target.cell:
        return target.cell
    return os.environ.get("NOVA_CELL", "cell")


def get_headers() -> dict[str, str]:
    """Build auth headers from environment if available."""
    headers: dict[str, str] = {}
    token = os.environ.get("NOVA_ACCESS_TOKEN") or os.environ.get("NOVA_API_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


# ── Model & config listing ────────────────────────────────────


async def fetch_model_ids(client: httpx.AsyncClient) -> list[str]:
    """Return all available motion-group-model IDs from the API."""
    api_base = get_api_base()
    resp = await client.get(f"{api_base}/motion-group-models")
    resp.raise_for_status()
    return cast("list[str]", resp.json())


async def fetch_config_ids(client: httpx.AsyncClient) -> list[str]:
    """Return all robot-configuration IDs (needed for controller creation)."""
    api_base = get_api_base()
    resp = await client.get(f"{api_base}/robot-configurations")
    resp.raise_for_status()
    return cast("list[str]", resp.json())


# ── Asset fetching (no controller needed) ─────────────────────


async def fetch_model_assets(
    client: httpx.AsyncClient,
    model_id: str,
) -> tuple[dict[str, object], dict[str, object], bytes]:
    """Fetch kinematic, collision, and GLB data in parallel."""
    api_base = get_api_base()
    kinematic_resp, collision_resp, glb_resp = await asyncio.gather(
        client.get(f"{api_base}/motion-group-models/{model_id}/kinematic"),
        client.get(f"{api_base}/motion-group-models/{model_id}/collision"),
        client.get(f"{api_base}/motion-group-models/{model_id}/glb"),
    )
    kinematic_resp.raise_for_status()
    glb_resp.raise_for_status()
    collision_data: dict[str, object] = {}
    if collision_resp.status_code == _HTTP_OK:
        collision_data = cast("dict[str, object]", collision_resp.json())
    else:
        logger.warning(
            "No collision data for %s (HTTP %s)", model_id, collision_resp.status_code
        )
    return (
        cast("dict[str, object]", kinematic_resp.json()),
        collision_data,
        glb_resp.content,
    )


# ── Controller lifecycle ──────────────────────────────────────


def config_id_for_model(model_id: str, config_ids: list[str]) -> str | None:
    """Find the robot-configuration ID that corresponds to a model ID.

    Model IDs look like ``FANUC_CRX25iA``, config IDs like ``fanuc-crx25ia``.
    """
    normalized = model_id.lower().replace("_", "")
    for cid in config_ids:
        if cid.lower().replace("-", "").replace("_", "") == normalized:
            return cid
    return None


def temp_controller_name(config_id: str) -> str:
    """Name for the throwaway controller one export creates.

    Suffixed so it cannot be the name of a controller somebody else owns, and
    so two exports of the same model do not fight over one name. Nova controller
    names end up as Kubernetes resource names, so this stays well inside 63
    characters for every configuration id the API serves.
    """
    base = config_id.replace(".", "-").replace("_", "-").lower()
    return f"{base}-{secrets.token_hex(2)}"


async def wait_for_controller(
    client: httpx.AsyncClient,
    ctrl_name: str,
    *,
    deadline_seconds: float = _CONTROLLER_TIMEOUT,
) -> None:
    """Poll until the controller description endpoint returns 200."""
    api_base = get_api_base()
    cell = get_cell()
    url = f"{api_base}/cells/{cell}/controllers/{ctrl_name}/description"
    deadline = time.monotonic() + deadline_seconds
    while time.monotonic() < deadline:
        try:
            resp = await client.get(url)
            if resp.status_code == _HTTP_OK:
                return
        except httpx.HTTPError:
            pass
        await asyncio.sleep(2)
    msg = f"Controller {ctrl_name} did not become ready within {deadline_seconds}s"
    raise TimeoutError(msg)


async def create_controller_and_fetch_metadata(
    client: httpx.AsyncClient,
    config_id: str,
) -> dict[str, object]:
    """Create a virtual controller, wait for it, fetch metadata, then tear down.

    The controller gets a name of our own rather than the model's, and is only
    torn down if this call is what created it: the teardown below deletes by
    name, and deleting a live controller because it happened to share a name
    with the model being exported is not a recoverable mistake.
    """
    api_base = get_api_base()
    cell = get_cell()
    manufacturer = config_id.split("-", maxsplit=1)[0]
    ctrl_name = temp_controller_name(config_id)
    created = False

    try:
        resp = await client.post(
            f"{api_base}/cells/{cell}/controllers",
            json={
                "name": ctrl_name,
                "configuration": {
                    "kind": "VirtualController",
                    "manufacturer": manufacturer,
                    "type": config_id,
                },
            },
        )
        resp.raise_for_status()
        created = True
        await wait_for_controller(client, ctrl_name)

        resp = await client.get(
            f"{api_base}/cells/{cell}/controllers/{ctrl_name}/description"
        )
        resp.raise_for_status()
        ctrl_desc = cast("dict[str, object]", resp.json())
        raw_mg_ids: object = ctrl_desc.get("connected_motion_groups", [])
        if not isinstance(raw_mg_ids, list) or not raw_mg_ids:
            return {}
        mg_id = cast("list[str]", raw_mg_ids)[0]

        url = (
            f"{api_base}/cells/{cell}/controllers/{ctrl_name}"
            + f"/motion-groups/{mg_id}/description"
        )
        resp = await client.get(url)
        resp.raise_for_status()
        return cast("dict[str, object]", resp.json())
    finally:
        if created:
            try:
                await client.delete(f"{api_base}/cells/{cell}/controllers/{ctrl_name}")
            except httpx.HTTPError:
                # Left running on the instance, and nothing else will remove it.
                logger.warning(
                    "Could not delete temporary controller %s — remove it by hand",
                    ctrl_name,
                )


async def fetch_controller_motion_groups(
    client: httpx.AsyncClient,
    controller_name: str,
) -> list[str]:
    """Ids of every motion group connected to a controller, in the API's order.

    A controller can drive several motion groups: each part of a multi-part
    robot (a carrier and the parts riding on it) is its own motion group.
    """
    api_base = get_api_base()
    cell = get_cell()

    resp = await client.get(
        f"{api_base}/cells/{cell}/controllers/{controller_name}/description"
    )
    resp.raise_for_status()
    ctrl_desc = cast("dict[str, object]", resp.json())
    raw_mg_ids: object = ctrl_desc.get("connected_motion_groups", [])
    if not isinstance(raw_mg_ids, list) or not raw_mg_ids:
        logger.error("Controller '%s' has no connected motion groups", controller_name)
        return []
    return cast("list[str]", raw_mg_ids)


async def fetch_controller_metadata(
    client: httpx.AsyncClient,
    controller_name: str,
    motion_group_id: str | None = None,
) -> tuple[str, dict[str, object]] | None:
    """Fetch one motion group's description from an existing controller.

    Defaults to the controller's first motion group. Pass *motion_group_id* to
    pick another; a multi-part robot needs every one of them.

    Returns ``(model_id, mg_description)`` or ``None`` on failure.
    """
    api_base = get_api_base()
    cell = get_cell()

    if motion_group_id is None:
        mg_ids = await fetch_controller_motion_groups(client, controller_name)
        if not mg_ids:
            return None
        motion_group_id = mg_ids[0]
    mg_id = motion_group_id

    url = (
        f"{api_base}/cells/{cell}/controllers/{controller_name}"
        + f"/motion-groups/{mg_id}/description"
    )
    resp = await client.get(url)
    resp.raise_for_status()
    mg_desc = cast("dict[str, object]", resp.json())

    model_id = str(mg_desc.get("motion_group_model", ""))
    if not model_id:
        logger.error("Controller '%s' motion group has no model ID", controller_name)
        return None

    return model_id, mg_desc


# ── Collision data fetching ───────────────────────────────────


async def _fetch_collision_collection(
    client: httpx.AsyncClient,
    url: str,
) -> dict[str, dict[str, object]]:
    """GET a collision collection endpoint; return parsed JSON or empty dict."""
    try:
        resp = await client.get(url)
        if resp.status_code != _HTTP_OK:
            return {}
        return cast("dict[str, dict[str, object]]", resp.json())
    except httpx.HTTPError:
        return {}


async def fetch_stored_tool_colliders(
    client: httpx.AsyncClient,
    tool_name: str | None = None,
) -> dict[str, dict[str, object]]:
    """Fetch user-defined stored tool collision data (raw dicts).

    If *tool_name* is given, fetches only that tool; otherwise all tools.
    """
    api_base = get_api_base()
    cell = get_cell()
    if tool_name:
        url = f"{api_base}/cells/{cell}/store/collision/tools/{tool_name}"
        try:
            resp = await client.get(url)
            if resp.status_code != _HTTP_OK:
                return {}
            return {"tool": cast("dict[str, object]", resp.json())}
        except httpx.HTTPError:
            return {}

    return await _fetch_collision_collection(
        client, f"{api_base}/cells/{cell}/store/collision/tools"
    )


async def fetch_collision_setups(
    client: httpx.AsyncClient,
) -> dict[str, dict[str, object]]:
    """Fetch safety-controller collision setups."""
    api_base = get_api_base()
    cell = get_cell()
    return await _fetch_collision_collection(
        client, f"{api_base}/cells/{cell}/store/collision/setups"
    )


async def fetch_stored_link_chains(
    client: httpx.AsyncClient,
) -> dict[str, list[object]]:
    """Fetch user-defined stored link-chains."""
    api_base = get_api_base()
    cell = get_cell()
    try:
        resp = await client.get(f"{api_base}/cells/{cell}/store/collision/link-chains")
        if resp.status_code != _HTTP_OK:
            return {}
        return cast("dict[str, list[object]]", resp.json())
    except httpx.HTTPError:
        logger.debug("Could not fetch stored link-chains")
        return {}


async def fetch_existing_controllers(
    client: httpx.AsyncClient,
) -> list[str]:
    """Return names of existing controllers on the Nova instance."""
    api_base = get_api_base()
    cell = get_cell()
    resp = await client.get(f"{api_base}/cells/{cell}/controllers")
    resp.raise_for_status()
    return cast("list[str]", resp.json())
