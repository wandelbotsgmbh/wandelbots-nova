"""Typed container for decoded mesh primitive data."""

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray


@dataclass(frozen=True)
class PrimitiveData:
    """Decoded mesh primitive with transformed vertices, normals, and faces."""

    vertices: NDArray[np.float32]
    normals: NDArray[np.float32] | None
    faces: NDArray[np.uint32]
    material_idx: int | None
