"""URDF exporter using DH parameters."""

from dataclasses import dataclass, field
import logging
from pathlib import Path
import re
import shutil
from typing import cast
from xml.dom import minidom  # noqa: S408
from xml.etree import ElementTree as ET  # noqa: S405

from .constants import (
    DEFAULT_EFFORT,
    DEFAULT_JOINT_LIMIT,
    DEFAULT_VELOCITY,
    MM_TO_M,
)
from .shape_converter import shape_to_mesh

logger = logging.getLogger(__name__)


@dataclass
class DHParam:
    """Denavit-Hartenberg parameters for a single joint."""

    alpha: float = 0.0
    theta: float = 0.0
    a: float = 0.0
    d: float = 0.0
    reverse_rotation_direction: bool = False


@dataclass
class Mounting:
    """Robot mounting position and orientation."""

    position: list[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    orientation: list[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])


@dataclass
class JointLimit:
    """Joint rotation limits."""

    lower_limit: float = -DEFAULT_JOINT_LIMIT
    upper_limit: float = DEFAULT_JOINT_LIMIT
    velocity: float = DEFAULT_VELOCITY
    effort: float = DEFAULT_EFFORT


def tcp_frame_name(tcp_id: str) -> str:
    """A TCP's id as a URDF link name: ``tcp_<id>``, kept legal and stable."""
    safe = re.sub(r"[^A-Za-z0-9_]+", "_", tcp_id).strip("_")
    return f"tcp_{safe or 'unnamed'}"


@dataclass
class TCPDefinition:
    """Tool center point definition."""

    name: str = "Flange"
    position: list[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    orientation: list[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    id: str = ""
    """The key the API uses for this TCP, which is what a caller names."""


@dataclass
class ToolCollider:
    """A collision shape attached to the tool (flange frame).

    Shapes are primitives (sphere, box, cylinder, capsule) or convex hulls.
    All dimensions are in **millimetres** (converted to metres during URDF export).
    """

    name: str = ""
    shape: dict[str, object] = field(default_factory=dict)
    position: list[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    orientation: list[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    margin: float = 0.0
    mount: str = ""
    """Frame the pose is stated in: a TCP id or name, ``tool0``, or empty for
    the flange, which is what the API uses. A robot with several tools states
    each one on its own TCP."""


@dataclass
class RobotModel:
    """Simple container for robot DH parameters."""

    dh_parameters: list[DHParam] = field(default_factory=list)
    mounting: Mounting = field(default_factory=Mounting)
    joint_limits: list[JointLimit] = field(default_factory=list)
    tcp: TCPDefinition = field(default_factory=TCPDefinition)
    tool_colliders: list[ToolCollider] = field(default_factory=list)
    tcps: list[TCPDefinition] = field(default_factory=list)
    """Every TCP this motion group defines, each emitted as its own frame."""
    safety_link_colliders: dict[int, list[ToolCollider]] = field(default_factory=dict)
    """The safety controller's volumes per link index, in that link's frame.

    A separate thing from the model's own collision meshes: the safety
    controller enforces these, they are usually larger, and a consumer wants to
    tell them apart -- so they go in as ``<collision>`` named ``safety_*``.
    """
    safety_tool_colliders: list[ToolCollider] = field(default_factory=list)
    """The safety controller's volumes for the tool, in the flange frame."""


@dataclass
class ChainExport:
    """One kinematic chain's contribution to a URDF.

    A controller with several motion groups becomes one URDF with one chain per
    motion group. ``parent_link`` is what the chain mounts on: ``world`` for a
    chain standing on the floor, or another chain's link when it physically
    rides on that chain (an arm on a carrier), so moving the parent moves the
    child. ``prefix`` namespaces every link and joint name.
    """

    robot: RobotModel
    prefix: str = ""
    parent_link: str = "world"
    collision_meshes_info: dict[int, list[dict[str, str]]] = field(default_factory=dict)
    visual_meshes_info: dict[int, list[dict[str, str]]] = field(default_factory=dict)

    @property
    def joint_names(self) -> list[str]:
        """Actuated joint names, in the motion group's joint order."""
        return [
            f"{self.prefix}q{index + 1}"
            for index in range(len(self.robot.dh_parameters))
        ]

    @property
    def flange_link(self) -> str:
        """Name of the link at the chain's flange."""
        return f"{self.prefix}link{len(self.robot.dh_parameters)}_passive"


class URDFExporter:
    """Exports one or more kinematic chains to a single URDF using DH parameters."""

    def __init__(  # noqa: PLR0913  # robot=/*_meshes_info are the single-chain shorthand for chains=
        self,
        robot: RobotModel | None = None,
        model_name: str = "example_robot",
        export_path: str | None = None,
        collision_meshes_info: dict[int, list[dict[str, str]]] | None = None,
        visual_meshes_info: dict[int, list[dict[str, str]]] | None = None,
        *,
        chains: list[ChainExport] | None = None,
        length_divisor: float = MM_TO_M,
        tool_assets: dict[str, str] | None = None,
    ) -> None:
        self.tool_assets = dict(tool_assets or {})
        """Mesh per mount frame -- a TCP id or name, ``tool0`` or ``flange``.
        The API serves no tool mesh, so a caller that has one (a viewer's tool
        asset, say) passes it here and the URDF carries it like any other
        geometry, on the frame it names."""
        self._mounted: set[str] = set()

        if chains is None:
            if robot is None:
                msg = "Pass either robot= or chains="
                raise ValueError(msg)
            chains = [
                ChainExport(
                    robot=robot,
                    collision_meshes_info=collision_meshes_info or {},
                    visual_meshes_info=visual_meshes_info or {},
                )
            ]
        self.chains = chains
        self.model_name = model_name or "example_robot"
        self.export_path = (
            Path(export_path) if export_path else Path.cwd() / "robot_export"
        )
        self.length_divisor = length_divisor
        """Millimetres per URDF length unit: 1000 for metres, 1 for millimetres."""

    # Single-chain accessors, kept so callers that pass robot= read naturally.
    @property
    def robot(self) -> RobotModel:
        """The first chain's robot model."""
        return self.chains[0].robot

    @property
    def collision_meshes_info(self) -> dict[int, list[dict[str, str]]]:
        """The first chain's collision meshes."""
        return self.chains[0].collision_meshes_info

    @property
    def visual_meshes_info(self) -> dict[int, list[dict[str, str]]]:
        """The first chain's visual meshes."""
        return self.chains[0].visual_meshes_info

    def _length(self, millimetres: float) -> float:
        """A millimetre value in the URDF's length unit."""
        return millimetres / self.length_divisor

    def build_xml(self) -> ET.Element:
        """Build the ``<robot>`` element tree, without touching disk."""
        robot_elem = ET.Element("robot")
        robot_elem.set("name", self.model_name)

        self._add_default_material(robot_elem)
        self._mounted.clear()
        for index, chain in enumerate(self.chains):
            base_link = self._add_base(robot_elem, chain, add_world=index == 0)
            self._add_joints_and_links(robot_elem, chain, base_link)

        for mount in self.tool_assets.keys() - self._mounted:
            logger.warning("No TCP or frame named %r to mount a tool mesh on", mount)
        return robot_elem

    def export_urdf(self, filename: str | None = None) -> str:
        """Export the URDF model to a file."""
        return self._write_urdf(self.build_xml(), filename)

    @staticmethod
    def _add_default_material(robot_elem: ET.Element) -> None:
        """Add default blue material."""
        default_material = ET.SubElement(robot_elem, "material")
        default_material.set("name", "blue")
        ET.SubElement(default_material, "color").set("rgba", "0 0 .8 1")

    def _add_base(
        self, robot_elem: ET.Element, chain: ChainExport, *, add_world: bool
    ) -> ET.Element:
        """Add the chain's base link and the fixed joint mounting it."""
        base_link = ET.SubElement(robot_elem, "link")
        base_link.set("name", f"{chain.prefix}link0_passive")
        self._add_meshes_to_link(base_link, chain, 0)

        if add_world:
            # One shared world link, which every chain mounts onto directly or
            # by way of the chain it rides on.
            ET.SubElement(robot_elem, "link").set("name", "world")

        mount_joint = ET.SubElement(robot_elem, "joint")
        mount_joint.set("name", f"{chain.prefix}world_mount")
        mount_joint.set("type", "fixed")
        ET.SubElement(mount_joint, "parent").set("link", chain.parent_link)
        ET.SubElement(mount_joint, "child").set("link", f"{chain.prefix}link0_passive")

        mount_origin = ET.SubElement(mount_joint, "origin")
        pos = chain.robot.mounting.position
        ori = chain.robot.mounting.orientation
        mount_origin.set(
            "xyz",
            f"{self._length(pos[0])} {self._length(pos[1])} {self._length(pos[2])}",
        )
        mount_origin.set("rpy", f"{ori[0]} {ori[1]} {ori[2]}")
        return base_link

    def _add_joints_and_links(
        self,
        robot_elem: ET.Element,
        chain: ChainExport,
        base_link: ET.Element | None = None,
    ) -> None:
        """Add all DH joints and links of one chain."""
        mounts: dict[str, ET.Element] = {}
        passive_links: dict[int, ET.Element] = {}
        if base_link is not None:
            passive_links[0] = base_link
        for i, dh in enumerate(chain.robot.dh_parameters):
            link_idx = i + 1
            self._add_active_link(robot_elem, chain, link_idx, dh)
            self._add_active_joint(robot_elem, chain, link_idx, i, dh)
            flange = self._add_passive_joint_and_link(robot_elem, chain, link_idx, dh)
            passive_links[link_idx] = flange
            mounts["flange"] = flange

        mounts["tool0"] = self._add_tool0_frame(robot_elem, chain)
        mounts.update(self._add_tcp_frames(robot_elem, chain))
        self._attach_tool_geometry(mounts, chain)
        self._attach_safety_geometry(passive_links, mounts, chain)

    def _add_active_link(
        self, robot_elem: ET.Element, chain: ChainExport, link_idx: int, dh: DHParam
    ) -> None:
        """Add an active link element."""
        link = ET.SubElement(robot_elem, "link")
        link.set("name", f"{chain.prefix}link{link_idx}")
        self._add_meshes_to_link(link, chain, link_idx, dh=dh)

    def _add_active_joint(
        self,
        robot_elem: ET.Element,
        chain: ChainExport,
        link_idx: int,
        joint_index: int,
        dh: DHParam,
    ) -> None:
        """Add an active revolute joint element."""
        joint = ET.SubElement(robot_elem, "joint")
        joint.set("name", f"{chain.prefix}q{link_idx}")
        joint.set("type", "revolute")

        origin = ET.SubElement(joint, "origin")
        origin.set("xyz", f"0 0 {self._length(dh.d)}")
        origin.set("rpy", f"0 0 {dh.theta}")

        ET.SubElement(joint, "parent").set(
            "link", f"{chain.prefix}link{link_idx - 1}_passive"
        )
        ET.SubElement(joint, "child").set("link", f"{chain.prefix}link{link_idx}")

        axis_z = "0 0 -1" if dh.reverse_rotation_direction else "0 0 1"
        ET.SubElement(joint, "axis").set("xyz", axis_z)

        limit = ET.SubElement(joint, "limit")
        if joint_index < len(chain.robot.joint_limits):
            jl = chain.robot.joint_limits[joint_index]
            limit.set("lower", str(jl.lower_limit))
            limit.set("upper", str(jl.upper_limit))
            limit.set("velocity", str(jl.velocity))
            limit.set("effort", str(jl.effort))
        else:
            limit.set("lower", str(-DEFAULT_JOINT_LIMIT))
            limit.set("upper", str(DEFAULT_JOINT_LIMIT))
            limit.set("velocity", str(DEFAULT_VELOCITY))
            limit.set("effort", str(DEFAULT_EFFORT))

    def _add_passive_joint_and_link(
        self,
        robot_elem: ET.Element,
        chain: ChainExport,
        link_idx: int,
        dh: DHParam,
    ) -> ET.Element:
        """Add passive joint and link for DH transformation part 2."""
        passive_joint = ET.SubElement(robot_elem, "joint")
        passive_joint.set("name", f"{chain.prefix}q{link_idx}_passive")
        passive_joint.set("type", "fixed")

        p_origin = ET.SubElement(passive_joint, "origin")
        p_origin.set("xyz", f"{self._length(dh.a)} 0 0")
        p_origin.set("rpy", f"{dh.alpha} 0 0")

        ET.SubElement(passive_joint, "parent").set(
            "link", f"{chain.prefix}link{link_idx}"
        )
        ET.SubElement(passive_joint, "child").set(
            "link", f"{chain.prefix}link{link_idx}_passive"
        )

        passive_link = ET.SubElement(robot_elem, "link")
        passive_link.set("name", f"{chain.prefix}link{link_idx}_passive")
        return passive_link

    def _add_tool0_frame(
        self, robot_elem: ET.Element, chain: ChainExport
    ) -> ET.Element:
        """Add a tool0 fixed frame at the active TCP (standard ROS convention).

        If a TCP with a non-zero offset is configured, the tool0 frame is
        placed at that offset from the flange.
        """
        tool_link = ET.SubElement(robot_elem, "link")
        tool_link.set("name", f"{chain.prefix}tool0")

        tool_joint = ET.SubElement(robot_elem, "joint")
        tool_joint.set("name", f"{chain.prefix}flange-tool0")
        tool_joint.set("type", "fixed")
        ET.SubElement(tool_joint, "parent").set("link", chain.flange_link)
        ET.SubElement(tool_joint, "child").set("link", f"{chain.prefix}tool0")

        tcp = chain.robot.tcp
        pos = tcp.position
        ori = tcp.orientation
        origin = ET.SubElement(tool_joint, "origin")
        origin.set(
            "xyz",
            f"{self._length(pos[0])} {self._length(pos[1])} {self._length(pos[2])}",
        )
        origin.set("rpy", f"{ori[0]} {ori[1]} {ori[2]}")
        return tool_link

    def _add_tcp_frames(
        self, robot_elem: ET.Element, chain: ChainExport
    ) -> dict[str, ET.Element]:
        """Add a frame per TCP the motion group defines.

        Every TCP goes in, not just one picked at export time: which tool a
        consumer cares about is its decision, a motion group can define several
        (a gripper, a tool changer, the bare flange), and on a multi-part robot
        they differ per part. All of them hang off the flange, so a consumer can
        read any of them without re-exporting.

        Returns each frame's link by TCP id and by TCP name, which is what tool
        geometry is mounted through.
        """
        mounts: dict[str, ET.Element] = {}
        for tcp in chain.robot.tcps:
            name = tcp_frame_name(tcp.id or tcp.name)
            link = ET.SubElement(robot_elem, "link")
            link.set("name", f"{chain.prefix}{name}")

            joint = ET.SubElement(robot_elem, "joint")
            joint.set("name", f"{chain.prefix}flange-{name}")
            joint.set("type", "fixed")
            ET.SubElement(joint, "parent").set("link", chain.flange_link)
            ET.SubElement(joint, "child").set("link", f"{chain.prefix}{name}")
            origin = ET.SubElement(joint, "origin")
            pos, ori = tcp.position, tcp.orientation
            origin.set(
                "xyz",
                f"{self._length(pos[0])} {self._length(pos[1])} {self._length(pos[2])}",
            )
            origin.set("rpy", f"{ori[0]} {ori[1]} {ori[2]}")

            for key in (tcp.id, tcp.name):
                if key:
                    mounts[key] = link
        return mounts

    def _attach_tool_geometry(
        self, mounts: dict[str, ET.Element], chain: ChainExport
    ) -> None:
        """Hang the tool's geometry on the frame it is stated in.

        The API states a tool collider in the flange frame, so that is the
        default, and a caller's mesh or a collider may name a TCP instead --
        by id or by name -- which is what a robot with more than one tool
        needs. Unknown names are reported once the whole export is done,
        because a name may belong to another part of a multi-part robot.
        """
        for collider in chain.robot.tool_colliders:
            link = mounts.get(collider.mount or "flange")
            if link is None:
                logger.warning(
                    "No frame %r on %s for tool collider %r",
                    collider.mount or "flange",
                    chain.prefix or self.model_name,
                    collider.name,
                )
                continue
            self._add_tool_collider(link, collider, chain)

        for mount in self.tool_assets:
            link = mounts.get(mount)
            if link is not None:
                self._add_tool_asset(link, mount, chain)
                self._mounted.add(mount)

    def _add_tool_asset(
        self, link_elem: ET.Element, mount: str, chain: ChainExport
    ) -> None:
        """Show the caller's tool mesh on the frame it named."""
        source = self.tool_assets.get(mount)
        if source is None:
            return
        origin = Path(source)
        if not origin.is_file():
            logger.warning("Tool mesh for %r not found: %s", mount, source)
            return

        visual_dir = self.export_path / "visual"
        visual_dir.mkdir(parents=True, exist_ok=True)
        target = (
            visual_dir / f"{chain.prefix}tool_{tcp_frame_name(mount)}{origin.suffix}"
        )
        shutil.copyfile(origin, target)

        visual = ET.SubElement(link_elem, "visual")
        visual.set("name", f"{chain.prefix}tool_asset_{tcp_frame_name(mount)}")
        vis_origin = ET.SubElement(visual, "origin")
        vis_origin.set("xyz", "0 0 0")
        vis_origin.set("rpy", "0 0 0")
        geometry = ET.SubElement(visual, "geometry")
        ET.SubElement(geometry, "mesh").set("filename", f"visual/{target.name}")

    def _attach_safety_geometry(
        self,
        passive_links: dict[int, ET.Element],
        mounts: dict[str, ET.Element],
        chain: ChainExport,
    ) -> None:
        """Add the safety controller's volumes, link by link and for the tool.

        A link's safety volume is stated in that link's own frame, which is the
        frame after the link's DH transform -- the passive link this exporter
        emits. The tool's are stated in the flange frame, like any tool
        collider.
        """
        for index, colliders in chain.robot.safety_link_colliders.items():
            link = passive_links.get(index)
            if link is None:
                logger.warning(
                    "%s has no link %d to hang a safety volume on",
                    chain.prefix or self.model_name,
                    index,
                )
                continue
            for collider in colliders:
                self._add_tool_collider(link, collider, chain)

        for collider in chain.robot.safety_tool_colliders:
            link = mounts.get(collider.mount or "flange")
            if link is not None:
                self._add_tool_collider(link, collider, chain)

    def _add_tool_collider(
        self, link_elem: ET.Element, collider: ToolCollider, chain: ChainExport
    ) -> None:
        """Add a single collider as a URDF collision element."""
        shape = collider.shape
        mesh = shape_to_mesh(
            shape, margin=collider.margin, length_divisor=self.length_divisor
        )
        if mesh is None:
            return

        collision = ET.SubElement(link_elem, "collision")
        # A safety volume says so in its own name; anything else is a tool's.
        name = (
            collider.name
            if collider.name.startswith("safety_")
            else f"tool_collision_{collider.name}"
        )
        collision.set("name", f"{chain.prefix}{name}")

        # Pose (mm to the URDF's length unit)
        col_origin = ET.SubElement(collision, "origin")
        pos = collider.position
        ori = collider.orientation
        col_origin.set(
            "xyz",
            f"{self._length(pos[0])} {self._length(pos[1])} {self._length(pos[2])}",
        )
        col_origin.set("rpy", f"{ori[0]} {ori[1]} {ori[2]}")

        # Export mesh to STL and reference it
        collision_dir = self.export_path / "collision"
        collision_dir.mkdir(parents=True, exist_ok=True)
        safe_name = name.replace(" ", "_").replace("/", "_")
        stl_path = collision_dir / f"{chain.prefix}{safe_name}.stl"
        mesh.export(str(stl_path))  # pyright: ignore[reportUnknownMemberType]

        geom = ET.SubElement(collision, "geometry")
        ET.SubElement(geom, "mesh").set("filename", f"collision/{stl_path.name}")

    def _write_urdf(self, robot_elem: ET.Element, filename: str | None) -> str:
        """Format and write URDF XML to file."""
        filename = filename or f"{self.model_name}.urdf"
        self.export_path.mkdir(parents=True, exist_ok=True)
        full_path = self.export_path / filename

        raw_string = cast("bytes", ET.tostring(robot_elem, encoding="utf-8"))
        pretty_xml: str = minidom.parseString(raw_string).toprettyxml(  # noqa: S318
            indent="  "
        )
        full_path.write_text(pretty_xml, encoding="utf-8")

        return str(full_path)

    def _add_meshes_to_link(
        self,
        link_element: ET.Element,
        chain: ChainExport,
        link_idx: int,
        *,
        dh: DHParam | None = None,
    ) -> None:
        """Add collision and visual meshes to a link element."""
        xyz, rpy = self._get_mesh_origin(dh)
        self._add_collision_meshes(link_element, chain, link_idx, xyz, rpy)
        self._add_visual_meshes(link_element, chain, link_idx, xyz, rpy)

    def _get_mesh_origin(self, dh: DHParam | None) -> tuple[str, str]:
        """Compute mesh origin from DH parameters."""
        if dh is not None:
            return f"{self._length(dh.a)} 0 0", f"{dh.alpha} 0 0"
        return "0 0 0", "0 0 0"

    @staticmethod
    def _add_collision_meshes(
        link_element: ET.Element,
        chain: ChainExport,
        mesh_idx: int,
        xyz: str,
        rpy: str,
    ) -> None:
        """Add collision mesh elements."""
        if mesh_idx not in chain.collision_meshes_info:
            return
        for mesh_info in chain.collision_meshes_info[mesh_idx]:
            basename = Path(mesh_info["file"]).name
            rel_path = f"collision/{basename}"

            collision = ET.SubElement(link_element, "collision")
            collision.set("name", f"{chain.prefix}collision_{mesh_info['collider_id']}")
            col_origin = ET.SubElement(collision, "origin")
            col_origin.set("xyz", xyz)
            col_origin.set("rpy", rpy)
            col_geom = ET.SubElement(collision, "geometry")
            ET.SubElement(col_geom, "mesh").set("filename", rel_path)

    @staticmethod
    def _add_visual_meshes(
        link_element: ET.Element,
        chain: ChainExport,
        mesh_idx: int,
        xyz: str,
        rpy: str,
    ) -> None:
        """Add visual mesh elements.

        A link the model gives no visual mesh keeps none: that is legal URDF and
        it is what the model says. The collision geometry is drawn see-through
        anyway, so such a link still reads as part of the robot.
        """
        if mesh_idx in chain.visual_meshes_info:
            for mesh_info in chain.visual_meshes_info[mesh_idx]:
                basename = Path(mesh_info["file"]).name
                rel_path = f"visual/{basename}"

                visual = ET.SubElement(link_element, "visual")
                visual.set("name", f"{chain.prefix}visual_{mesh_info['node_name']}")
                vis_origin = ET.SubElement(visual, "origin")
                vis_origin.set("xyz", xyz)
                vis_origin.set("rpy", rpy)
                vis_geom = ET.SubElement(visual, "geometry")
                ET.SubElement(vis_geom, "mesh").set("filename", rel_path)
