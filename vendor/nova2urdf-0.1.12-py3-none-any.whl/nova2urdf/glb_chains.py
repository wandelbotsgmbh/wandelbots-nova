"""Kinematic chain structure read out of a robot GLB's node hierarchy.

Nova authors every robot GLB with one node per joint frame, named
``<PREFIX>_J<NN>``, ending in a ``<PREFIX>_FLG`` flange node, and hangs each
link's geometry off the joint node above it. A model that is one part of a
larger robot also carries the *other* parts as static decoration, with their
node names suffixed ``_save``.

That decoration is what tells us how the parts fit together: the part that
carries the others hangs their ``_J00_save`` nodes off one of its own joint
nodes, so those chains mount there and ride along when it moves. This module is
the single place that reads all of it.

Everything returned here is Z-up (the URDF/DH convention), converted from the
GLB's Y-up by a similarity transform.
"""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import TYPE_CHECKING

import numpy as np
import pygltflib
from scipy.spatial.transform import Rotation

if TYPE_CHECKING:
    from numpy.typing import NDArray

# glTF is Y-up, DH and URDF are Z-up. Converting a *transform* between
# conventions is a similarity transform, not a left-multiply.
YUP_TO_ZUP: NDArray[np.float64] = np.array(
    [[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]], dtype=np.float64
)

_JOINT_NODE = re.compile(r"^(?P<prefix>.*)_J(?P<index>\d+)(?P<save>_save)?$")
_FLANGE_NODE = re.compile(r"^(?P<prefix>.*)_FLG(?P<save>_save)?$")
_LINK_NODE = re.compile(r"^(?:.*_)?link_?(?P<index>\d+)$", re.IGNORECASE)


def _normalise(name: str) -> str:
    """Strip separators and case so model ids and node prefixes can be compared."""
    return re.sub(r"[^A-Za-z0-9]", "", name).upper()


def _tokens(name: str) -> set[str]:
    """Uppercase words of a node or prefix name."""
    return {word for word in re.split(r"[^A-Za-z0-9]+", name.upper()) if word}


@dataclass(frozen=True)
class ChainNode:
    """One ``_J<NN>`` or ``_FLG`` node of a chain."""

    node: int
    name: str
    prefix: str
    index: int
    """Joint index; the flange sorts after every joint."""
    is_decoration: bool
    """True for a ``_save`` node: another part's chain, present as scenery."""


@dataclass
class Attachment:
    """Where a decoration chain hangs on the model's own chain."""

    prefix: str
    joint_index: int
    """Index of the owning chain's joint node the decoration hangs off."""


class GlbChains:
    """Node hierarchy of one robot GLB, indexed for chain queries."""

    def __init__(self, glb: pygltflib.GLTF2) -> None:
        self._glb = glb
        self._names = [node.name or "" for node in glb.nodes]
        self._parent: dict[int, int] = {
            child: index
            for index, node in enumerate(glb.nodes)
            for child in (node.children or [])
        }
        self._world: dict[int, NDArray[np.float64]] = {}
        self._nodes = self._index_chain_nodes()

    # ── construction ────────────────────────────────────────────

    @classmethod
    def from_bytes(cls, data: bytes) -> GlbChains:
        """Parse a GLB blob. Only the JSON chunk is read; geometry is ignored."""
        return cls(pygltflib.GLTF2.load_from_bytes(data))

    def _index_chain_nodes(self) -> list[ChainNode]:
        found: list[ChainNode] = []
        for index, name in enumerate(self._names):
            if match := _JOINT_NODE.match(name):
                found.append(
                    ChainNode(
                        node=index,
                        name=name,
                        prefix=match["prefix"],
                        index=int(match["index"]),
                        is_decoration=bool(match["save"]),
                    )
                )
            elif match := _FLANGE_NODE.match(name):
                found.append(
                    ChainNode(
                        node=index,
                        name=name,
                        prefix=match["prefix"],
                        # The flange terminates the chain, so it sorts last.
                        index=1 << 16,
                        is_decoration=bool(match["save"]),
                    )
                )
        return found

    # ── geometry ────────────────────────────────────────────────

    def local_transform(self, node: int) -> NDArray[np.float64]:
        """This node's transform relative to its parent, in GLB (Y-up) space."""
        spec = self._glb.nodes[node]
        if spec.matrix:
            # glTF stores matrices column-major.
            return np.array(spec.matrix, dtype=np.float64).reshape(4, 4).T
        transform = np.eye(4)
        if spec.rotation:
            transform[:3, :3] = Rotation.from_quat(spec.rotation).as_matrix()
        if spec.scale:
            transform[:3, :3] @= np.diag(spec.scale)
        if spec.translation:
            transform[:3, 3] = spec.translation
        return transform

    def world_transform(self, node: int) -> NDArray[np.float64]:
        """This node's transform relative to the scene root, in GLB (Y-up) space."""
        if node not in self._world:
            local = self.local_transform(node)
            parent = self._parent.get(node)
            self._world[node] = (
                self.world_transform(parent) @ local if parent is not None else local
            )
        return self._world[node]

    def world_transform_zup(self, node: int) -> NDArray[np.float64]:
        """This node's world transform, converted to Z-up."""
        return YUP_TO_ZUP @ self.world_transform(node) @ np.linalg.inv(YUP_TO_ZUP)

    # ── chain queries ───────────────────────────────────────────

    def prefixes(self, *, include_decoration: bool = False) -> list[str]:
        """Chain prefixes present in this GLB, longest chain first."""
        counts: dict[str, int] = {}
        for node in self._nodes:
            if node.is_decoration and not include_decoration:
                continue
            counts[node.prefix] = counts.get(node.prefix, 0) + 1
        return sorted(counts, key=lambda prefix: (-counts[prefix], prefix))

    def own_prefix(self, model_id: str) -> str | None:
        """The prefix of the chain this GLB is the model *of*.

        Matched against ``model_id`` rather than taken positionally: every part
        of a multi-part robot carries the other parts' chains too, and node
        order does not favour the model's own.
        """
        candidates = self.prefixes()
        if not candidates:
            return None
        wanted = _normalise(model_id)
        for prefix in candidates:
            if _normalise(prefix) == wanted:
                return prefix
        # A single non-decoration chain is unambiguous even if the model id was
        # renamed relative to the authored prefix.
        return candidates[0] if len(candidates) == 1 else None

    def chain(self, prefix: str, *, decoration: bool = False) -> list[ChainNode]:
        """This chain's nodes in kinematic order, flange last."""
        return sorted(
            (
                node
                for node in self._nodes
                if node.prefix == prefix and node.is_decoration == decoration
            ),
            key=lambda node: node.index,
        )

    def root_node(self, prefix: str, *, decoration: bool = False) -> ChainNode | None:
        """The chain's first joint node."""
        chain = self.chain(prefix, decoration=decoration)
        return chain[0] if chain else None

    def mounting_zup(
        self, prefix: str, *, decoration: bool = False
    ) -> NDArray[np.float64]:
        """Where this chain's base sits, in Z-up metres.

        The API reports a zero mounting for every motion group of a multi-part
        robot, but the GLB has the chain root authored at its real placement.
        """
        root = self.root_node(prefix, decoration=decoration)
        return self.world_transform_zup(root.node) if root else np.eye(4)

    def attachment(self, prefix: str, owner_prefix: str) -> Attachment | None:
        """Which of ``owner_prefix``'s joints the ``prefix`` decoration hangs off.

        This is how a child part learns that it rides on its parent: the answer
        is authored in the parent's GLB, as the decoration's position in the
        node tree.
        """
        root = self.root_node(prefix, decoration=True)
        if root is None:
            return None
        owned = {node.node: node for node in self.chain(owner_prefix)}
        node = self._parent.get(root.node)
        while node is not None:
            if found := owned.get(node):
                return Attachment(prefix=prefix, joint_index=found.index)
            node = self._parent.get(node)
        return None

    # ── link geometry ───────────────────────────────────────────

    def _foreign_tokens(self, prefix: str) -> set[str]:
        """Name words that mark a node as belonging to another part of the robot.

        Decoration geometry is not consistently parented under the decoration
        chain: a carrying part hangs another part's link and tool meshes
        straight off one of its own joint nodes. Their names still say whose
        they are.
        """
        own = _tokens(prefix)
        foreign: set[str] = set()
        for other in self.prefixes(include_decoration=True):
            if other != prefix:
                foreign |= _tokens(other) - own
        return foreign

    def static_meshes(self, prefix: str) -> list[tuple[int, int, str]]:
        """Mesh nodes belonging to no chain at all: the robot's fixed structure.

        A base cabinet can be half a million vertices hanging at the scene
        root, under no joint, so a rule that only takes ``link_0`` and the mesh
        children of joint nodes drops the whole thing and the robot floats. It
        is rigid relative to the robot's base, so it belongs on link 0.

        Only the part at the robot's base should contribute these: every model
        carries a copy, and taking them from each would draw the base four times.
        """
        chain = {node.node for node in self.chain(prefix)}
        decoration = {node.node for node in self._nodes if node.is_decoration}
        foreign = self._foreign_tokens(prefix)
        found: list[tuple[int, int, str]] = []

        for index, node in enumerate(self._glb.nodes):
            if node.mesh is None or index in chain:
                continue
            name = self._names[index] or f"node_{index}"
            if _LINK_NODE.match(name) or (_tokens(name) & foreign):
                continue  # a link's own shell, or named after another part
            ancestor, owned = self._parent.get(index), False
            while ancestor is not None:
                if ancestor in chain or ancestor in decoration:
                    owned = True
                    break
                ancestor = self._parent.get(ancestor)
            if not owned:
                found.append((index, node.mesh, name))
        return found

    def link_meshes(self, prefix: str) -> dict[int, list[tuple[int, int, str]]]:
        """Mesh nodes per kinematic link index, as ``(node, mesh, name)``.

        Link 0 is the base: the model's own ``link_0`` node. Link *k* is carried
        by the mesh nodes parented to joint node *k-1*. A joint can own more than
        one mesh (a tool beside the link shell), so all of them are kept, with
        ``link_<k>``-style names first so the link's own shell leads.
        """
        chain = self.chain(prefix)
        foreign = self._foreign_tokens(prefix)
        result: dict[int, list[tuple[int, int, str]]] = {}

        for index, name in enumerate(self._names):
            if name == "link_0" and (mesh := self._glb.nodes[index].mesh) is not None:
                result[0] = [(index, mesh, name)]
                break

        for position, joint in enumerate(chain):
            meshes: list[tuple[int, int, str]] = []
            for child in self._glb.nodes[joint.node].children or []:
                mesh = self._glb.nodes[child].mesh
                name = self._names[child] or f"node_{child}"
                if mesh is not None and not (_tokens(name) & foreign):
                    meshes.append((child, mesh, name))
            if meshes:
                meshes.sort(key=lambda entry: _LINK_NODE.match(entry[2]) is None)
                result[position + 1] = meshes
        return result
